module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 2);
/******/ })
/************************************************************************/
/******/ ({

/***/ 2:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("gxbQ");


/***/ }),

/***/ "MCK1":
/***/ (function(module, exports) {

module.exports = require("faker");

/***/ }),

/***/ "gxbQ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "faker"
var external_faker_ = __webpack_require__("MCK1");
var external_faker_default = /*#__PURE__*/__webpack_require__.n(external_faker_);

// EXTERNAL MODULE: ./libs/firebase.ts
var firebase = __webpack_require__("sQGF");

// CONCATENATED MODULE: ./photos.js
const photos = ["/photos/841303/pexels-photo-841303.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/211047/pexels-photo-211047.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/164767/pexels-photo-164767.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/543368/pexels-photo-543368.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/547557/pexels-photo-547557.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/789555/pexels-photo-789555.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/720337/pexels-photo-720337.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/678444/pexels-photo-678444.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/321545/pexels-photo-321545.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/259618/pexels-photo-259618.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/678451/pexels-photo-678451.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/551573/pexels-photo-551573.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/906101/pexels-photo-906101.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/162520/farmer-man-shepherd-dog-162520.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/414807/pexels-photo-414807.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/286305/pexels-photo-286305.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/754595/pexels-photo-754595.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/1187005/pexels-photo-1187005.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/592931/pexels-photo-592931.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/6555/nature-sunset-person-woman.jpg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/981091/pexels-photo-981091.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/615293/pexels-photo-615293.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/105905/pexels-photo-105905.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/361104/pexels-photo-361104.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/1129394/pexels-photo-1129394.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/592940/pexels-photo-592940.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/211046/pexels-photo-211046.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/1088295/pexels-photo-1088295.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/721999/pexels-photo-721999.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/1147152/pexels-photo-1147152.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/941253/pexels-photo-941253.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/460985/pexels-photo-460985.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/478541/pexels-photo-478541.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/735182/pexels-photo-735182.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/695342/pexels-photo-695342.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/682373/pexels-photo-682373.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/259806/pexels-photo-259806.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/56617/early-morning-autumn-fall-forest-56617.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/1128527/pexels-photo-1128527.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/1340496/pexels-photo-1340496.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/157929/city-corner-out-going-pm-ta-woman-157929.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/596893/pexels-photo-596893.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/605494/pexels-photo-605494.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/137031/pexels-photo-137031.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/577697/pexels-photo-577697.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/206893/pexels-photo-206893.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/716565/pexels-photo-716565.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/144234/bull-landscape-nature-mammal-144234.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/257849/pexels-photo-257849.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/7643/pexels-photo.jpg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/750108/pexels-photo-750108.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/734972/pexels-photo-734972.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/906088/pexels-photo-906088.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/371404/pexels-photo-371404.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/911802/pexels-photo-911802.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/250446/pexels-photo-250446.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/755023/pexels-photo-755023.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/952632/pexels-photo-952632.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/462119/pexels-photo-462119.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/537053/pexels-photo-537053.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/3363359/pexels-photo-3363359.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/1327350/pexels-photo-1327350.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/2660212/pexels-photo-2660212.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/923114/pexels-photo-923114.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/2086264/pexels-photo-2086264.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/1806270/pexels-photo-1806270.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/1837607/pexels-photo-1837607.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/2007614/pexels-photo-2007614.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/1145366/pexels-photo-1145366.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/2664046/pexels-photo-2664046.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/1771265/pexels-photo-1771265.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/2189692/pexels-photo-2189692.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", "/photos/3684926/pexels-photo-3684926.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"];
// CONCATENATED MODULE: ./helpers/index.ts
const categories = ["people", "pets", "landmarks", "cities", "nature", "food", "premium"];
const imageUrls = ["https://res.cloudinary.com/young-einstein/image/upload/v1619536750/Rectangle_2_kgiwhv.png", "https://res.cloudinary.com/young-einstein/image/upload/v1619536749/Rectangle_2.4_sosme5.png", "https://res.cloudinary.com/young-einstein/image/upload/v1619536749/Rectangle_2.1_zopgmt.png", "https://res.cloudinary.com/young-einstein/image/upload/v1619536747/Rectangle_10_gna1lr.png"];
const getRandomImage = () => imageUrls[Math.floor(Math.random() * imageUrls.length)];
const getRandomCategory = () => categories[Math.floor(Math.random() * categories.length)];
// CONCATENATED MODULE: ./pages/api/products.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





/* harmony default export */ var api_products = __webpack_exports__["default"] = (async (req, res) => {
  try {
    if (req.method === "POST") {
      const incomingProduct = req.body;
      await firebase["a" /* db */].collection("mainProducts").add(_objectSpread(_objectSpread({}, incomingProduct), {}, {
        created: new Date().getTime()
      }));
      let products = [];
      photos.forEach(async photo => {
        const product = {
          name: external_faker_default.a.commerce.productName(),
          category: getRandomCategory(),
          price: Number(external_faker_default.a.commerce.price()),
          currency: "USD",
          image: photo,
          bestseller: external_faker_default.a.datatype.boolean(),
          featured: false,
          details: null
        };
        await firebase["a" /* db */].collection("mainProducts").add(_objectSpread(_objectSpread({}, product), {}, {
          created: new Date().getTime()
        }));
        products.push(product);
      });
      res.status(201).send({
        status: "success",
        data: [incomingProduct, ...products]
      });
    }

    if (req.method === "GET") {
      const snapshot = await firebase["a" /* db */].collection("products").get();
      const data = snapshot.docs.map(doc => _objectSpread(_objectSpread({}, doc.data()), {}, {
        id: doc.id
      }));
      return res.status(200).send({
        status: "success",
        data
      });
    }
  } catch (e) {
    console.log(e);
    res.status(500).send({
      success: false,
      message: "Something went wrong"
    });
  }
});

/***/ }),

/***/ "pNaP":
/***/ (function(module, exports) {

module.exports = require("firebase");

/***/ }),

/***/ "sQGF":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return db; });
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("pNaP");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_0__);

const config = {
  apiKey: "AIzaSyBMZj-_kOItk2OYKtDHZSeeqvOMN5JUX0E",
  authDomain: "naijafries-21386.firebaseapp.com",
  projectId: "naijafries-21386"
};

if (!firebase__WEBPACK_IMPORTED_MODULE_0___default.a.apps.length) {
  try {
    firebase__WEBPACK_IMPORTED_MODULE_0___default.a.initializeApp(config);
  } catch (error) {
    console.log("Firebase admin initialization error", error.stack);
  }
}

const db = firebase__WEBPACK_IMPORTED_MODULE_0___default.a.firestore();


/***/ })

/******/ });