module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 3);
/******/ })
/************************************************************************/
/******/ ({

/***/ "+2xy":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"productCart": "cart_productCart__3aS4T",
	"closeCartBtn": "cart_closeCartBtn__TUHHC",
	"clearCartBtn": "cart_clearCartBtn__1Tu0y"
};


/***/ }),

/***/ "0G5g":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.cancelIdleCallback = exports.requestIdleCallback = void 0;

const requestIdleCallback = typeof self !== 'undefined' && self.requestIdleCallback || function (cb) {
  let start = Date.now();
  return setTimeout(function () {
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      }
    });
  }, 1);
};

exports.requestIdleCallback = requestIdleCallback;

const cancelIdleCallback = typeof self !== 'undefined' && self.cancelIdleCallback || function (id) {
  return clearTimeout(id);
};

exports.cancelIdleCallback = cancelIdleCallback;

/***/ }),

/***/ "1ccW":
/***/ (function(module, exports) {

function _extends() {
  module.exports = _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

module.exports = _extends;

/***/ }),

/***/ "23aj":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, "getStaticProps", function() { return /* binding */ getStaticProps; });

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__("xnum");
var head_default = /*#__PURE__*/__webpack_require__.n(head_);

// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__("IZS3");

// EXTERNAL MODULE: ./context/index.ts + 3 modules
var context = __webpack_require__("4rth");

// CONCATENATED MODULE: ./components/SVGs/AngleDown.tsx


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const AngleDown = props => {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", _objectSpread(_objectSpread({}, props), {}, {
    width: "20",
    height: "13",
    viewBox: "0 0 20 13",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M2 2L10 10L18 2",
      stroke: "black",
      strokeWidth: "3"
    })
  }));
};
// CONCATENATED MODULE: ./components/SVGs/ArrowDown.tsx


function ArrowDown_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function ArrowDown_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ArrowDown_ownKeys(Object(source), true).forEach(function (key) { ArrowDown_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ArrowDown_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function ArrowDown_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const ArrowDown = props => {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", ArrowDown_objectSpread(ArrowDown_objectSpread({}, props), {}, {
    width: "7",
    height: "15",
    viewBox: "0 0 7 15",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M3.45919 14.6367C3.53276 14.7103 3.6278 14.7471 3.7259 14.7471C3.824 14.7471 3.91903 14.7103 3.99261 14.6367L6.8896 11.7397C7.03675 11.5926 7.03675 11.3565 6.8896 11.2094C6.74245 11.0622 6.5064 11.0622 6.35925 11.2094L4.10297 13.4657V0.626917C4.10297 0.418456 3.93436 0.249847 3.7259 0.249847C3.51744 0.249847 3.34883 0.418456 3.34883 0.626917V13.4657L1.09561 11.2094C0.948458 11.0622 0.712406 11.0622 0.565257 11.2094C0.418108 11.3565 0.418108 11.5926 0.565257 11.7397L3.45919 14.6367Z",
      fill: "currentColor"
    })
  }));
};
// CONCATENATED MODULE: ./components/SVGs/ArrowUp.tsx


function ArrowUp_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function ArrowUp_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ArrowUp_ownKeys(Object(source), true).forEach(function (key) { ArrowUp_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ArrowUp_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function ArrowUp_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const ArrowUp = props => {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", ArrowUp_objectSpread(ArrowUp_objectSpread({}, props), {}, {
    width: "7",
    height: "15",
    viewBox: "0 0 7 15",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M3.64807 14.3734V1.5347L5.90435 3.79098C5.97793 3.86456 6.07296 3.90134 6.17106 3.90134C6.26916 3.90134 6.36419 3.86456 6.43777 3.79098C6.58492 3.64383 6.58492 3.40778 6.43777 3.26063L3.54077 0.363637C3.39976 0.222619 3.15144 0.222619 3.01042 0.363637L0.110362 3.26063C-0.0367873 3.40778 -0.0367873 3.64383 0.110362 3.79098C0.257511 3.93813 0.493562 3.93813 0.640711 3.79098L2.897 1.5347V14.3734C2.897 14.5819 3.0656 14.7505 3.27407 14.7505C3.47946 14.7474 3.64807 14.5788 3.64807 14.3734Z",
      fill: "currentColor"
    })
  }));
};
// CONCATENATED MODULE: ./components/SVGs/FilterToggle.tsx



function FilterToggle_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function FilterToggle_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { FilterToggle_ownKeys(Object(source), true).forEach(function (key) { FilterToggle_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { FilterToggle_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function FilterToggle_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const FilterToggle = props => {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("svg", FilterToggle_objectSpread(FilterToggle_objectSpread({}, props), {}, {
    width: "29",
    height: "29",
    viewBox: "0 0 29 29",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M23.8119 0H5.18805C2.32736 0 0 2.32736 0 5.18805V23.812C0 26.6726 2.32736 29 5.18805 29H23.812C26.6726 29 29 26.6726 29 23.8119V5.18805C29 2.32736 26.6726 0 23.8119 0ZM27.3008 23.8119C27.3008 25.7357 25.7357 27.3008 23.8119 27.3008H5.18805C3.26431 27.3008 1.69922 25.7357 1.69922 23.8119V5.18805C1.69922 3.26431 3.26431 1.69922 5.18805 1.69922H23.812C25.7357 1.69922 27.3008 3.26431 27.3008 5.18805V23.8119Z",
      fill: "black"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M24.5103 6.3702H11.5701C11.2143 5.31357 10.2149 4.55017 9.03986 4.55017C7.86479 4.55017 6.86537 5.31357 6.50961 6.3702H4.48975C4.02054 6.3702 3.64014 6.7506 3.64014 7.21981C3.64014 7.68902 4.02054 8.06942 4.48975 8.06942H6.50966C6.86542 9.12605 7.86485 9.88946 9.03991 9.88946C10.215 9.88946 11.2144 9.12605 11.5702 8.06942H24.5103C24.9795 8.06942 25.3599 7.68902 25.3599 7.21981C25.3599 6.7506 24.9795 6.3702 24.5103 6.3702ZM9.03986 8.19024C8.50477 8.19024 8.06943 7.7549 8.06943 7.21981C8.06943 6.68473 8.50477 6.24939 9.03986 6.24939C9.57494 6.24939 10.0103 6.68473 10.0103 7.21981C10.0103 7.7549 9.57494 8.19024 9.03986 8.19024Z",
      fill: "black"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M24.5103 13.6504H22.4904C22.1346 12.5938 21.1351 11.8304 19.9601 11.8304C18.7851 11.8304 17.7857 12.5938 17.4299 13.6504H4.48975C4.02054 13.6504 3.64014 14.0308 3.64014 14.5C3.64014 14.9692 4.02054 15.3496 4.48975 15.3496H17.4299C17.7857 16.4063 18.7852 17.1697 19.9602 17.1697C21.1352 17.1697 22.1347 16.4063 22.4904 15.3496H24.5103C24.9795 15.3496 25.3599 14.9692 25.3599 14.5C25.3599 14.0308 24.9795 13.6504 24.5103 13.6504ZM19.9602 15.4704C19.4251 15.4704 18.9897 15.0351 18.9897 14.5C18.9897 13.9649 19.4251 13.5296 19.9602 13.5296C20.4953 13.5296 20.9306 13.9649 20.9306 14.5C20.9306 15.0351 20.4953 15.4704 19.9602 15.4704Z",
      fill: "black"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M24.5103 20.9306H15.2102C14.8545 19.8739 13.855 19.1105 12.68 19.1105C11.5049 19.1105 10.5055 19.8739 10.1497 20.9306H4.48975C4.02054 20.9306 3.64014 21.311 3.64014 21.7802C3.64014 22.2494 4.02054 22.6298 4.48975 22.6298H10.1497C10.5055 23.6864 11.5049 24.4498 12.68 24.4498C13.855 24.4498 14.8545 23.6864 15.2102 22.6298H24.5103C24.9795 22.6298 25.3599 22.2494 25.3599 21.7802C25.3599 21.311 24.9795 20.9306 24.5103 20.9306ZM12.68 22.7507C12.1449 22.7507 11.7096 22.3153 11.7096 21.7802C11.7096 21.2452 12.1449 20.8098 12.68 20.8098C13.2151 20.8098 13.6504 21.2451 13.6504 21.7802C13.6504 22.3153 13.2151 22.7507 12.68 22.7507Z",
      fill: "black"
    })]
  }));
};
// CONCATENATED MODULE: ./components/SVGs/CloseBtn.tsx



function CloseBtn_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function CloseBtn_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { CloseBtn_ownKeys(Object(source), true).forEach(function (key) { CloseBtn_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { CloseBtn_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function CloseBtn_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const CloseBtn = props => {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("svg", CloseBtn_objectSpread(CloseBtn_objectSpread({}, props), {}, {
    width: "22",
    height: "22",
    viewBox: "0 0 22 22",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M2 2L20 20",
      stroke: "black",
      strokeWidth: "4"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M2 20L20 2",
      stroke: "black",
      strokeWidth: "4"
    })]
  }));
};
// CONCATENATED MODULE: ./components/SVGs/AngleRight.tsx


function AngleRight_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function AngleRight_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { AngleRight_ownKeys(Object(source), true).forEach(function (key) { AngleRight_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { AngleRight_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function AngleRight_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const AngleRight = props => {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", AngleRight_objectSpread(AngleRight_objectSpread({}, props), {}, {
    width: "13",
    height: "20",
    viewBox: "0 0 13 20",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M2 2L10 10L2 18",
      stroke: "black",
      strokeWidth: "3"
    })
  }));
};
// CONCATENATED MODULE: ./components/SVGs/AngleLeft.tsx


function AngleLeft_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function AngleLeft_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { AngleLeft_ownKeys(Object(source), true).forEach(function (key) { AngleLeft_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { AngleLeft_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function AngleLeft_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const AngleLeft = props => {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("svg", AngleLeft_objectSpread(AngleLeft_objectSpread({}, props), {}, {
    width: "13",
    height: "20",
    viewBox: "0 0 13 20",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M11 2L3 10L11 18",
      stroke: "black",
      strokeWidth: "3"
    })
  }));
};
// CONCATENATED MODULE: ./components/SVGs/Cart.tsx



function Cart_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Cart_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Cart_ownKeys(Object(source), true).forEach(function (key) { Cart_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Cart_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Cart_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const Cart = props => {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("svg", Cart_objectSpread(Cart_objectSpread({}, props), {}, {
    width: "54",
    height: "54",
    viewBox: "0 0 54 54",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M17.3982 34.9106H17.4007C17.4028 34.9106 17.4048 34.9102 17.4069 34.9102H46.0898C46.796 34.9102 47.4169 34.4417 47.6109 33.7628L53.939 11.6143C54.0754 11.1368 53.9798 10.6235 53.6811 10.2272C53.382 9.83084 52.9144 9.59766 52.418 9.59766H13.7497L12.6188 4.50838C12.4577 3.78452 11.8158 3.26953 11.0742 3.26953H1.58203C0.708206 3.26953 0 3.97774 0 4.85156C0 5.72539 0.708206 6.43359 1.58203 6.43359H9.8053C10.0055 7.33543 15.2172 30.7882 15.5171 32.1375C13.8358 32.8683 12.6562 34.5447 12.6562 36.4922C12.6562 39.1091 14.7854 41.2383 17.4023 41.2383H46.0898C46.9637 41.2383 47.6719 40.5301 47.6719 39.6562C47.6719 38.7824 46.9637 38.0742 46.0898 38.0742H17.4023C16.5302 38.0742 15.8203 37.3644 15.8203 36.4922C15.8203 35.6212 16.5277 34.9126 17.3982 34.9106ZM50.3205 12.7617L44.8963 31.7461H18.6713L14.4525 12.7617H50.3205Z",
      fill: "black"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M15.8203 45.9844C15.8203 48.6013 17.9495 50.7305 20.5664 50.7305C23.1834 50.7305 25.3125 48.6013 25.3125 45.9844C25.3125 43.3674 23.1834 41.2383 20.5664 41.2383C17.9495 41.2383 15.8203 43.3674 15.8203 45.9844ZM20.5664 44.4023C21.4386 44.4023 22.1484 45.1122 22.1484 45.9844C22.1484 46.8566 21.4386 47.5664 20.5664 47.5664C19.6942 47.5664 18.9844 46.8566 18.9844 45.9844C18.9844 45.1122 19.6942 44.4023 20.5664 44.4023Z",
      fill: "black"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M38.1797 45.9844C38.1797 48.6013 40.3088 50.7305 42.9258 50.7305C45.5427 50.7305 47.6719 48.6013 47.6719 45.9844C47.6719 43.3674 45.5427 41.2383 42.9258 41.2383C40.3088 41.2383 38.1797 43.3674 38.1797 45.9844ZM42.9258 44.4023C43.798 44.4023 44.5078 45.1122 44.5078 45.9844C44.5078 46.8566 43.798 47.5664 42.9258 47.5664C42.0536 47.5664 41.3438 46.8566 41.3438 45.9844C41.3438 45.1122 42.0536 44.4023 42.9258 44.4023Z",
      fill: "black"
    })]
  }));
};
// CONCATENATED MODULE: ./components/SVGs/Logo.tsx



const Logo = props => {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("svg", {
    width: "159",
    height: "26",
    viewBox: "0 0 159 26",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M2.32147 21.285C1.0124 21.285 0 20.3016 0 19.1388V2.41514C0 1.19315 1.07178 0.268677 2.32147 0.268677H7.35162C11.8153 0.268677 14.0474 3.13084 14.0474 6.11101C14.0474 8.19808 12.7084 9.47939 10.9228 10.3445C12.7678 11.089 14.6132 12.4313 14.6132 15.0234C14.6132 18.5124 11.8152 21.2853 7.23258 21.2853H2.32147V21.285ZM7.58926 8.49596C8.63104 8.49596 9.88064 7.78026 9.88064 6.17068C9.88064 5.03883 9.34484 4.02456 7.79734 4.02456H4.16679V8.49604H7.58926V8.49596ZM4.16687 12.3118V17.498H7.49987C9.46414 17.498 10.4467 16.5152 10.4467 14.9638C10.4467 13.2645 9.2565 12.3118 7.67856 12.3118H4.16687Z",
      fill: "black"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M32.4668 21.285H24.5801C23.1219 21.285 21.8131 20.7779 21.8131 19.1685V2.38506C21.8131 1.34214 22.7945 0.268555 24.1046 0.268555H32.1692C33.3007 0.268555 34.2526 1.16306 34.2526 2.20616C34.2526 3.27992 33.3007 4.05449 32.1692 4.05449H25.9795V8.85382H31.6043C32.6455 8.85382 33.6579 9.65826 33.6579 10.7321C33.6579 11.8046 32.7645 12.6398 31.6043 12.6398H25.9795V17.4979H32.4668C33.5684 17.4979 34.5503 18.3331 34.5503 19.3473C34.5503 20.4212 33.5986 21.285 32.4668 21.285Z",
      fill: "black"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M50.5002 14.2793C50.5002 18.8095 48.8936 21.5533 43.5965 21.5533C42.4649 21.5533 40.1732 21.4341 40.1732 19.4964C40.1732 18.3035 41.2747 17.6169 42.1077 17.6169C42.7926 17.6169 43.1797 17.7962 43.923 17.7962C45.9166 17.7962 46.3338 16.455 46.3338 14.279V1.90755C46.3337 0.864894 47.2268 0 48.4173 0C49.5177 0 50.5003 0.894769 50.5003 1.90764L50.5002 14.2793Z",
      fill: "black"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M99.3941 19.6752C99.3941 20.6885 98.4409 21.5533 97.3401 21.5533C96.2098 21.5533 95.2271 20.6885 95.2271 19.6752V9.4194L91.8348 16.0972C91.4477 16.8714 90.7031 17.2294 89.8706 17.2294C89.0666 17.2294 88.3232 16.8714 87.936 16.0972L84.5436 9.4194V19.6753C84.5436 20.6886 83.5609 21.5534 82.4009 21.5534C81.2692 21.5534 80.3771 20.6886 80.3771 19.6753V1.96757C80.3771 0.835193 81.299 0.000262063 82.5198 0.000262063C83.4717 0.000262063 84.216 0.38794 84.6032 1.16321L89.9002 11.6855L95.1974 1.13351C95.6145 0.268614 96.4172 0 97.2509 0C98.4709 0 99.3941 0.894769 99.3941 1.96739V19.6752Z",
      fill: "black"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M122.902 18.9894L117.099 2.02714C116.682 0.835106 116.086 0 114.658 0C113.23 0 112.635 0.864894 112.247 2.02705L106.444 18.9893C106.385 19.1386 106.356 19.4966 106.356 19.6457C106.356 20.7781 107.337 21.5535 108.498 21.5535C109.212 21.5535 110.165 21.0166 110.462 20.1528C110.462 20.1528 114.539 6.64783 114.658 5.72371C114.777 6.64783 118.825 20.1528 118.825 20.1528C119.123 20.9871 120.074 21.5535 120.848 21.5535C122.069 21.5535 122.992 20.7781 122.992 19.6457C122.992 19.4966 122.962 19.1387 122.902 18.9894Z",
      fill: "black"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M73.5939 18.9894L67.7906 2.02714C67.3735 0.835106 66.7783 0 65.3502 0C63.9218 0 63.3262 0.864894 62.9389 2.02705L57.1358 18.9893C57.0761 19.1386 57.0474 19.4966 57.0474 19.6457C57.0474 20.7781 58.0289 21.5535 59.1892 21.5535C59.9039 21.5535 60.8566 21.0166 61.1535 20.1528C61.1535 20.1528 65.2307 6.64783 65.3502 5.72371C65.469 6.64783 69.5167 20.1528 69.5167 20.1528C69.8144 20.9871 70.766 21.5535 71.54 21.5535C72.7599 21.5535 73.6829 20.7781 73.6829 19.6457C73.683 19.4966 73.6536 19.1387 73.5939 18.9894Z",
      fill: "black"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M137.81 13.1752C137.185 12.9078 136.442 12.6398 135.638 12.3714C132.722 11.4765 129.566 10.4932 129.566 6.17061C129.566 2.32537 132.245 0 136.472 0C138.227 0 142.452 0.447341 142.452 2.68335C142.452 3.66669 141.679 4.56137 140.37 4.56137C139.834 4.56137 139.417 4.38239 138.911 4.23345C138.346 4.02432 137.691 3.78611 136.65 3.78611C135.191 3.78611 133.822 4.29302 133.822 6.05129C133.822 7.36256 134.567 7.81008 135.072 8.04855C135.846 8.43632 136.561 8.67488 137.215 8.85387C140.132 9.77755 143.316 10.7916 143.316 15.0233C143.316 19.1685 140.162 21.5535 135.905 21.5535C133.703 21.5535 129.536 20.7781 129.536 18.6901C129.536 17.7366 130.4 16.812 131.501 16.812C131.947 16.812 132.424 16.9611 132.989 17.1702C133.703 17.4088 134.656 17.7668 135.935 17.7668C137.989 17.7668 139.03 16.8419 139.03 15.2025C139.03 13.8611 138.346 13.4141 137.81 13.1752Z",
      fill: "black"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("path", {
      d: "M156.946 21.4302C157.989 21.4302 159 22.2645 159 23.338C159 24.4108 158.108 25.2159 156.946 25.2159H149.021C147.861 25.2159 146.967 24.4108 146.967 23.338C146.967 22.2645 147.98 21.4302 149.021 21.4302H156.946Z",
      fill: "black"
    })]
  });
};
// CONCATENATED MODULE: ./components/SVGs/index.ts









// EXTERNAL MODULE: ./components/Layout/layout.module.scss
var layout_module = __webpack_require__("5E+q");
var layout_module_default = /*#__PURE__*/__webpack_require__.n(layout_module);

// CONCATENATED MODULE: ./components/Layout/index.tsx







function Layout({
  children
}) {
  const {
    container,
    column,
    row,
    addToCartBtn,
    cartCount
  } = layout_module_default.a;
  const {
    openCart,
    cart: {
      cartItems
    }
  } = Object(context["c" /* useCartContext */])();
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: container,
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: row,
      children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
        className: column,
        children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])(head_default.a, {
          children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("title", {
            children: "Product List | Bejamas"
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("link", {
            rel: "icon",
            href: "/favicon.ico"
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("meta", {
            name: "description",
            content: "Bejamas Product List"
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("meta", {
            charSet: "utf-8"
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("meta", {
            name: "viewport",
            content: "initial-scale=1.0, width=device-width"
          })]
        }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("nav", {
          className: "d-flex justify-content-between align-items-center py-3",
          children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
            children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(Logo, {})
          }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])(external_react_bootstrap_["Button"], {
            onClick: () => openCart(),
            className: addToCartBtn,
            variant: "light",
            children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(Cart, {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
              className: cartCount,
              children: cartItems.length
            })]
          })]
        }), children]
      })
    })
  });
}
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__("Aiso");
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);

// EXTERNAL MODULE: ./components/Loader/loader.module.scss
var loader_module = __webpack_require__("gLdB");
var loader_module_default = /*#__PURE__*/__webpack_require__.n(loader_module);

// CONCATENATED MODULE: ./components/Loader/index.tsx



const Loader = () => {
  const {
    loader,
    spinner
  } = loader_module_default.a;
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: loader,
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: spinner
    })
  });
};
// EXTERNAL MODULE: ./components/FeaturedProduct/featuredProduct.module.scss
var featuredProduct_module = __webpack_require__("HcGf");
var featuredProduct_module_default = /*#__PURE__*/__webpack_require__.n(featuredProduct_module);

// CONCATENATED MODULE: ./components/FeaturedProduct/index.tsx








const {
  featuredProduct,
  featured_img__wrapper,
  more_details,
  description,
  wrapper: FeaturedProduct_wrapper,
  addToCartBtn: FeaturedProduct_addToCartBtn,
  similar_products,
  similar_product__img,
  photoOfDay
} = featuredProduct_module_default.a;
const FeaturedProduct = ({
  products: productList
}) => {
  const {
    isLoading
  } = Object(context["d" /* useProductContext */])();
  const {
    addProductToCart
  } = Object(context["c" /* useCartContext */])();
  const fetdProduct = productList.length ? productList.find(product => product.featured === true) : null;
  const name = fetdProduct === null || fetdProduct === void 0 ? void 0 : fetdProduct.name;
  const image = fetdProduct === null || fetdProduct === void 0 ? void 0 : fetdProduct.image;
  const category = fetdProduct === null || fetdProduct === void 0 ? void 0 : fetdProduct.category;
  const details = fetdProduct === null || fetdProduct === void 0 ? void 0 : fetdProduct.details;
  const {
    dimmensions,
    size,
    description: productDescription,
    recommendations
  } = details && details;
  const {
    width,
    height
  } = dimmensions && dimmensions;
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: `${featuredProduct} pt-5`,
    children: isLoading ? /*#__PURE__*/Object(jsx_runtime_["jsx"])(Loader, {}) : /*#__PURE__*/Object(jsx_runtime_["jsxs"])(external_react_["Fragment"], {
      children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("header", {
        className: "d-flex justify-content-between align-items-center mb-4",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h1", {
          children: name
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_bootstrap_["Button"], {
          onClick: () => addProductToCart(fetdProduct),
          className: "",
          variant: "dark",
          children: "ADD TO CART"
        })]
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
        className: `${featured_img__wrapper} mb-5`,
        children: [image && typeof image === "object" && /*#__PURE__*/Object(jsx_runtime_["jsx"])(image_default.a, {
          src: image.src,
          alt: image.alt,
          width: 1636,
          height: 726,
          layout: "responsive"
        }), image && typeof image === "string" && /*#__PURE__*/Object(jsx_runtime_["jsx"])(image_default.a, {
          src: image,
          alt: "Featured Image",
          width: 1636,
          height: 726
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
          className: photoOfDay,
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {
            children: "Photo of the day"
          })
        })]
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: `${FeaturedProduct_addToCartBtn} my-5`,
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_bootstrap_["Button"], {
          onClick: () => addProductToCart(fetdProduct),
          className: "",
          variant: "dark",
          children: "ADD TO CART"
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])(external_react_bootstrap_["Row"], {
        className: more_details,
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_bootstrap_["Col"], {
          sm: 12,
          md: 12,
          lg: 8,
          children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
            className: description,
            children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h2", {
              children: productDescription && `About the ${name}`
            }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
              children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("strong", {
                children: category
              })
            }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
              children: productDescription
            })]
          })
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_bootstrap_["Col"], {
          sm: 12,
          md: 12,
          lg: 4,
          children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
            className: similar_products,
            children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h2", {
              children: "People also buy"
            }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
              className: `${FeaturedProduct_wrapper} mb-5`,
              children: recommendations.map((recommendation, idx) => /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
                className: similar_product__img,
                children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(image_default.a, {
                  src: recommendation.src,
                  alt: recommendation.alt,
                  width: 117,
                  height: 147,
                  layout: "responsive"
                })
              }, idx))
            }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
              children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h2", {
                children: "Details"
              }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
                children: width && height && `Size: ${width} x ${height} pixel`
              }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
                children: size && `Size: ${size / 1000}mb`
              })]
            })]
          })
        })]
      })]
    })
  });
};
// EXTERNAL MODULE: ./components/ProductSorter/productSorter.module.scss
var productSorter_module = __webpack_require__("Dcqv");
var productSorter_module_default = /*#__PURE__*/__webpack_require__.n(productSorter_module);

// EXTERNAL MODULE: ./components/Button/button.module.scss
var button_module = __webpack_require__("TmFx");
var button_module_default = /*#__PURE__*/__webpack_require__.n(button_module);

// CONCATENATED MODULE: ./components/Button/index.tsx


function Button_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Button_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Button_ownKeys(Object(source), true).forEach(function (key) { Button_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Button_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Button_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }




const Button = (_ref) => {
  let {
    children,
    className
  } = _ref,
      rest = _objectWithoutProperties(_ref, ["children", "className"]);

  const {
    customBtn
  } = button_module_default.a;
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_bootstrap_["Button"], Button_objectSpread(Button_objectSpread({
    variant: "light",
    className: `${customBtn} ${className}`
  }, rest), {}, {
    children: children
  }));
};
// CONCATENATED MODULE: ./components/ProductSorter/index.tsx







const ProductSorter = () => {
  const {
    0: order,
    1: setOrder
  } = Object(external_react_["useState"])(null);
  const {
    0: sortValue,
    1: setSortValue
  } = Object(external_react_["useState"])("price");
  const {
    productSorter,
    orderSort,
    priceSort,
    sortControls,
    asc,
    desc
  } = productSorter_module_default.a;
  const {
    sortByPrice,
    sortByAlphabets
  } = Object(context["d" /* useProductContext */])();

  const handleAsc = () => {
    setOrder("asc");

    if (sortValue === "price") {
      sortByPrice("asc");
    } else {
      sortByAlphabets("asc");
    }
  };

  const handleDesc = () => {
    setOrder("desc");

    if (sortValue === "price") {
      sortByPrice("desc");
    } else {
      sortByAlphabets("desc");
    }
  };

  const handleProductSort = value => {
    setSortValue(value);

    if (value === "price") {
      sortByPrice(order);
    } else {
      sortByAlphabets(order);
    }
  };

  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: `${productSorter} d-flex align-items-center`,
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: `${orderSort} d-flex align-items-center`,
      children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
        className: `${sortControls} pr-3`,
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(Button, {
          onClick: () => handleAsc(),
          className: order === "asc" ? asc : "",
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(ArrowUp, {})
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(Button, {
          onClick: () => handleDesc(),
          className: order === "desc" ? desc : "",
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(ArrowDown, {})
        })]
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        className: "mr-2 mb-0",
        htmlFor: "productSort",
        children: "Sort By"
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("select", {
        onChange: e => {
          const value = e.target.value;
          console.log(value);
          handleProductSort(value);
        },
        defaultValue: "price",
        name: "productSort",
        id: "productSort",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("option", {
          value: "price",
          children: "Price"
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("option", {
          value: "alphabets",
          children: "Alphabets"
        })]
      })]
    })
  });
};
// EXTERNAL MODULE: ./components/ProductFilter/_partials/CategoryFilter/categoryFilter.module.scss
var categoryFilter_module = __webpack_require__("pk4n");
var categoryFilter_module_default = /*#__PURE__*/__webpack_require__.n(categoryFilter_module);

// CONCATENATED MODULE: ./components/ProductFilter/_partials/CategoryFilter/index.tsx



function CategoryFilter_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function CategoryFilter_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { CategoryFilter_ownKeys(Object(source), true).forEach(function (key) { CategoryFilter_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { CategoryFilter_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function CategoryFilter_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const CategoryFilter = ({
  isMobile,
  toggleFilterModal
}) => {
  const {
    0: checked,
    1: setChecked
  } = Object(external_react_["useState"])({});
  const {
    0: filters,
    1: setFilters
  } = Object(external_react_["useState"])([]);
  const {
    categoryFilter
  } = categoryFilter_module_default.a;
  const {
    data: productData,
    filterByCategory
  } = Object(context["d" /* useProductContext */])();
  const productCategories = [...new Set(productData.map(product => product.category))];

  const handleCategoryFilter = filters => {
    filterByCategory(filters);
  };

  const handleChange = e => {
    const {
      name: checkName,
      checked: isChecked
    } = e.target;
    setChecked(CategoryFilter_objectSpread(CategoryFilter_objectSpread({}, checked), {}, {
      [checkName]: isChecked
    }));

    if (isChecked) {
      // Check If previos filters are available
      if (filters.length) {
        // console.log("Has Filters", filters);
        // Remove Filter if its equal to the incoming filter
        filters.includes(checkName) ? handleCategoryFilter(filters) : handleCategoryFilter([...filters, checkName]);
      } else {
        // console.log("Has No Filters");
        handleCategoryFilter([...filters, checkName]);
      }
    } else {
      handleCategoryFilter(filters.filter(filter => filter !== checkName));
    }

    isChecked ? setFilters([...filters, checkName]) : setFilters(filters.filter(filter => filter !== checkName));
  };

  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: `${categoryFilter} pb-4`,
    children: [isMobile ? /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "d-flex align-items-center justify-content-between",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h4", {
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("strong", {
          children: "Filter"
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
        onClick: () => toggleFilterModal(),
        className: "",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(CloseBtn, {})
      })]
    }) : /*#__PURE__*/Object(jsx_runtime_["jsx"])("h3", {
      children: "Category"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "mt-4",
      children: productCategories.map((category, idx) => /*#__PURE__*/Object(jsx_runtime_["jsxs"])("label", {
        className: "d-flex align-items-center my-3 text-capitalize",
        htmlFor: category === null || category === void 0 ? void 0 : category.toLowerCase(),
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("input", {
          checked: checked[category] || false,
          onChange: e => handleChange(e),
          className: "mr-3",
          type: "checkbox",
          name: category === null || category === void 0 ? void 0 : category.toLowerCase(),
          id: category === null || category === void 0 ? void 0 : category.toLowerCase()
        }), category === null || category === void 0 ? void 0 : category.toLowerCase()]
      }, idx))
    })]
  });
};
// EXTERNAL MODULE: ./components/ProductFilter/_partials/PriceFilter/priceFilter.module.scss
var priceFilter_module = __webpack_require__("5CT0");
var priceFilter_module_default = /*#__PURE__*/__webpack_require__.n(priceFilter_module);

// CONCATENATED MODULE: ./components/ProductFilter/_partials/PriceFilter/index.tsx



function PriceFilter_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function PriceFilter_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { PriceFilter_ownKeys(Object(source), true).forEach(function (key) { PriceFilter_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { PriceFilter_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function PriceFilter_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const PriceFilter = () => {
  const {
    0: checked,
    1: setChecked
  } = Object(external_react_["useState"])({});
  const {
    0: filters,
    1: setFilters
  } = Object(external_react_["useState"])([]);
  const {
    priceFilter
  } = priceFilter_module_default.a;
  const {
    filterByPrice
  } = Object(context["d" /* useProductContext */])();

  const handleCategoryFilter = filters => {
    filterByPrice(filters);
  };

  const handleChange = e => {
    const {
      name: checkName,
      checked: isChecked
    } = e.target;
    setChecked(PriceFilter_objectSpread(PriceFilter_objectSpread({}, checked), {}, {
      [checkName]: isChecked
    }));
    const [min, max] = checkName.split(" - ");
    const prevFilter = filters.filter(filter => {
      let name = [filter.min, filter.max].join(" - ");
      name !== checkName;
    });

    if (isChecked) {
      // Check If previos filters are available
      if (filters.length) {
        // console.log("Has Filters", filters);
        // Remove Filter if its equal to the incoming filter
        filters.includes({
          min,
          max
        }) ? handleCategoryFilter(filters) : handleCategoryFilter([...filters, {
          min,
          max
        }]);
      } else {
        // console.log("Has No Filters");
        handleCategoryFilter([...filters, {
          min,
          max
        }]);
      }
    } else {
      handleCategoryFilter(prevFilter);
    }

    isChecked ? setFilters([...filters, {
      min,
      max
    }]) : setFilters(prevFilter);
  };

  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: `${priceFilter} mt-4`,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h3", {
      children: "Price"
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "mt-4",
      children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("label", {
        className: "d-flex align-items-center my-3",
        htmlFor: "priceFilter",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("input", {
          className: "mr-3",
          type: "checkbox",
          name: "20 - 100",
          id: "priceFilter",
          checked: checked["20 - 100"] || false,
          onChange: e => handleChange(e)
        }), "$20 - $100"]
      })
    })]
  });
};
// EXTERNAL MODULE: ./components/ProductFilter/productFilter.module.scss
var productFilter_module = __webpack_require__("pXDl");
var productFilter_module_default = /*#__PURE__*/__webpack_require__.n(productFilter_module);

// CONCATENATED MODULE: ./components/ProductFilter/index.tsx






const ProductFilter = () => {
  const {
    productFilter
  } = productFilter_module_default.a;
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: `${productFilter} px-4`,
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("aside", {
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(CategoryFilter, {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])(PriceFilter, {})]
    })
  });
};
// EXTERNAL MODULE: ./components/Pagination/pagnation.module.scss
var pagnation_module = __webpack_require__("JR2A");
var pagnation_module_default = /*#__PURE__*/__webpack_require__.n(pagnation_module);

// CONCATENATED MODULE: ./components/Pagination/index.tsx







const Pagination = props => {
  const {
    productsPerPage,
    totalProducts,
    paginate,
    currentPage,
    nextPage,
    prevPage
  } = Object(context["d" /* useProductContext */])();
  const {
    pagination,
    pageItem,
    pagelink,
    active
  } = pagnation_module_default.a;
  const pageNumbers = [];

  for (let i = 1; i <= Math.ceil(totalProducts / productsPerPage); i++) {
    pageNumbers.push(i);
  }

  const lastPage = pageNumbers[pageNumbers.length - 1];
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("footer", {
    className: "mt-3 mb-5 d-flex justify-content-center align-items-center",
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("ul", {
      className: `${pagination} pagination`,
      children: [currentPage > 1 && /*#__PURE__*/Object(jsx_runtime_["jsx"])(Button, {
        onClick: () => prevPage(),
        className: "mr-2",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(AngleLeft, {})
      }), pageNumbers.map(number => /*#__PURE__*/Object(jsx_runtime_["jsx"])("li", {
        className: `${pageItem} page-item`,
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
          onClick: e => {
            e.preventDefault();
            paginate(number);
          },
          href: "!#",
          className: `${pagelink} ${currentPage === number && active} page-link`,
          children: number
        })
      }, number)), currentPage !== lastPage && /*#__PURE__*/Object(jsx_runtime_["jsx"])(Button, {
        onClick: () => nextPage(),
        className: "ml-2",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(AngleRight, {})
      })]
    })
  });
};
// EXTERNAL MODULE: ./components/ProductItem/product.module.scss
var product_module = __webpack_require__("rDcf");
var product_module_default = /*#__PURE__*/__webpack_require__.n(product_module);

// CONCATENATED MODULE: ./components/ProductItem/index.tsx






const ProductItem = ({
  product
}) => {
  const {
    0: isMouseOnProduct,
    1: setIsMouseOnProduct
  } = Object(external_react_["useState"])(false);
  const {
    addProductToCart
  } = Object(context["c" /* useCartContext */])();
  const {
    productItem,
    wrapper,
    productCover,
    productTag,
    productName,
    productPrice,
    bestSellerFlag,
    addToCart
  } = product_module_default.a;
  const {
    name,
    category,
    price,
    image,
    bestseller
  } = product;

  const handleMouseEnter = () => setIsMouseOnProduct(true);

  const handleMouseLeave = () => setIsMouseOnProduct(false);

  const ProductCover = image && typeof image === "string" && image || typeof image === "object" && image.src;
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: `${productItem} py-3`,
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: wrapper,
      children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
        onMouseEnter: () => handleMouseEnter(),
        onMouseLeave: () => handleMouseLeave(),
        className: "position-relative",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(image_default.a, {
          src: ProductCover,
          alt: name,
          width: 310,
          height: 415,
          layout: "responsive"
        }), bestseller && /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
          className: bestSellerFlag,
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {
            children: "Best Seller"
          })
        }), isMouseOnProduct && /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
          className: addToCart,
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
            onClick: () => addProductToCart(product),
            children: "ADD TO CART"
          })
        })]
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
        className: `${productTag} text-capitalize mb-0`,
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("strong", {
          children: category
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("h2", {
        className: `${productName} text-capitalize`,
        children: name
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("p", {
        className: productPrice,
        children: ["$", price]
      })]
    })
  });
};
// EXTERNAL MODULE: ./components/ProductList/productList.module.scss
var productList_module = __webpack_require__("mMNo");
var productList_module_default = /*#__PURE__*/__webpack_require__.n(productList_module);

// CONCATENATED MODULE: ./components/ProductList/index.tsx








const ProductList = () => {
  const {
    productList
  } = productList_module_default.a;
  const {
    currentProducts
  } = Object(context["d" /* useProductContext */])();
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: "d-flex flex-column flex-grow-1 ml-md-4",
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_bootstrap_["Row"], {
      className: `${productList}`,
      children: currentProducts.map((product, idx) => /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_bootstrap_["Col"], {
        xs: 12,
        sm: 6,
        md: 6,
        lg: 4,
        className: "mb-5",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(ProductItem, {
          product: product
        })
      }, idx))
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(Pagination, {})]
  });
};
// EXTERNAL MODULE: ./components/ProductSection/productSection.module.scss
var productSection_module = __webpack_require__("krTd");
var productSection_module_default = /*#__PURE__*/__webpack_require__.n(productSection_module);

// EXTERNAL MODULE: ./components/MobileFilter/mobileFilter.module.scss
var mobileFilter_module = __webpack_require__("8ep0");
var mobileFilter_module_default = /*#__PURE__*/__webpack_require__.n(mobileFilter_module);

// CONCATENATED MODULE: ./components/MobileFilter/index.tsx







const MobileFilter = ({
  isOpen,
  toggleFilterModal
}) => {
  const {
    modal100w,
    modalContent,
    modalBody,
    modalFooter
  } = mobileFilter_module_default.a;

  const clearFilters = () => {};

  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])(external_react_bootstrap_["Modal"], {
    show: isOpen,
    onHide: () => toggleFilterModal(),
    dialogClassName: modal100w,
    contentClassName: modalContent,
    "aria-labelledby": "example-custom-modal-styling-title",
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_bootstrap_["Modal"].Body, {
      className: modalBody,
      children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
        className: "w-100",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(CategoryFilter, {
          isMobile: isOpen,
          toggleFilterModal: toggleFilterModal
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(PriceFilter, {})]
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("footer", {
      className: `${modalFooter} d-flex align-items-center px-3 pt-4 pb-3`,
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
        className: "mr-2",
        onClick: () => clearFilters(),
        children: "CLEAR"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
        className: "ml-2",
        onClick: () => toggleFilterModal(),
        children: "SAVE"
      })]
    })]
  });
};
// CONCATENATED MODULE: ./components/ProductSection/index.tsx










const ProductSection = () => {
  const {
    0: isMobileFilterOpen,
    1: setIsMobileFilterOpen
  } = Object(external_react_["useState"])(false);
  const {
    productSection,
    productWrapper,
    category,
    filterToggle
  } = productSection_module_default.a;

  const toggleFilterModal = () => setIsMobileFilterOpen(open => !open);

  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("section", {
    className: `${productSection} mt-5`,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("header", {
      className: "d-flex align-items-center justify-content-between",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
        className: `${category} d-flex align-items-center flex-wrap`,
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("strong", {
            children: "Photography"
          })
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("strong", {
            className: "mx-md-4",
            children: "/"
          })
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
          children: "Premium Photos"
        })]
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(ProductSorter, {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])(Button, {
        onClick: () => toggleFilterModal(),
        className: filterToggle,
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(FilterToggle, {})
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: `${productWrapper} d-flex`,
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(ProductFilter, {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])(ProductList, {}), isMobileFilterOpen ? /*#__PURE__*/Object(jsx_runtime_["jsx"])(MobileFilter, {
        isOpen: isMobileFilterOpen,
        toggleFilterModal: toggleFilterModal
      }) : null]
    })]
  });
};
// EXTERNAL MODULE: ./components/CartItem/cartItem.module.scss
var cartItem_module = __webpack_require__("WbnN");
var cartItem_module_default = /*#__PURE__*/__webpack_require__.n(cartItem_module);

// CONCATENATED MODULE: ./components/CartItem/index.tsx





const CartItem = ({
  cartItem
}) => {
  const {
    cartItemWrapper,
    productDetails,
    productImg,
    name,
    price
  } = cartItem_module_default.a;
  const {
    product
  } = cartItem;
  const {
    image,
    name: productName,
    price: productPrice
  } = product;
  const ProductCover = image && typeof image === "string" && image || typeof image === "object" && image.src;
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: `${cartItemWrapper} d-flex justify-content-between align-items-center p-3`,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: productDetails,
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
        className: `${name}`,
        children: productName
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("p", {
        className: price,
        children: ["$", productPrice]
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: productImg,
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(image_default.a, {
        src: ProductCover,
        alt: name,
        height: 86,
        width: 150
      })
    })]
  });
};
// EXTERNAL MODULE: ./components/Cart/cart.module.scss
var cart_module = __webpack_require__("+2xy");
var cart_module_default = /*#__PURE__*/__webpack_require__.n(cart_module);

// CONCATENATED MODULE: ./components/Cart/index.tsx







const Cart_Cart = () => {
  const {
    productCart,
    clearCartBtn,
    closeCartBtn
  } = cart_module_default.a;
  const {
    cart,
    closeCart,
    clearCart
  } = Object(context["c" /* useCartContext */])();
  const {
    cartItems
  } = cart;
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: productCart,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: `${closeCartBtn} d-flex align-items-center justify-content-end`,
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
        onClick: () => closeCart(),
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(CloseBtn, {})
      })
    }), cartItems.length ? cartItems.map((cartItem, idx) => /*#__PURE__*/Object(jsx_runtime_["jsx"])(CartItem, {
      cartItem: cartItem
    }, idx)) : /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
      className: "text-center mt-2",
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("strong", {
        children: "No Products in Cart"
      })
    }), cartItems.length > 0 && /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: `${clearCartBtn} mt-3`,
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
        onClick: () => clearCart(),
        children: "CLEAR CART"
      })
    })]
  });
};
// CONCATENATED MODULE: ./components/index.ts






// EXTERNAL MODULE: ./libs/firebase.ts
var firebase = __webpack_require__("sQGF");

// CONCATENATED MODULE: ./pages/index.tsx



function pages_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function pages_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { pages_ownKeys(Object(source), true).forEach(function (key) { pages_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { pages_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function pages_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






const Home = ({
  products
}) => {
  const {
    loadProducts
  } = Object(context["d" /* useProductContext */])();
  Object(external_react_["useEffect"])(() => {
    loadProducts(products);
  }, []);
  const {
    cart: {
      isOpen
    }
  } = Object(context["c" /* useCartContext */])();
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(Layout, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("main", {
      className: "product-list",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(FeaturedProduct, {
        products: products
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(ProductSection, {}), isOpen ? /*#__PURE__*/Object(jsx_runtime_["jsx"])(Cart_Cart, {}) : null]
    })
  });
};

const getStaticProps = async () => {
  const snapshot = await firebase["a" /* db */].collection("mainProducts").get();
  const data = snapshot.docs.map(doc => pages_objectSpread(pages_objectSpread({}, doc.data()), {}, {
    id: doc.id
  }));
  return {
    props: {
      products: data
    }
  };
};
/* harmony default export */ var pages = __webpack_exports__["default"] = (Home);

/***/ }),

/***/ 3:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("23aj");


/***/ }),

/***/ "4rth":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "b", function() { return /* reexport */ ProductProvider; });
__webpack_require__.d(__webpack_exports__, "d", function() { return /* reexport */ useProductContext; });
__webpack_require__.d(__webpack_exports__, "a", function() { return /* reexport */ CartProvider; });
__webpack_require__.d(__webpack_exports__, "c", function() { return /* reexport */ useCartContext; });

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");

// CONCATENATED MODULE: ./context/Products/helpers.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function sortAsc(arr, field) {
  return arr.sort(function (a, b) {
    if (a[field] > b[field]) {
      return 1;
    }

    if (b[field] > a[field]) {
      return -1;
    }

    return 0;
  });
}
function sortDesc(arr, field) {
  return arr.sort(function (a, b) {
    if (a[field] > b[field]) {
      return -1;
    }

    if (b[field] > a[field]) {
      return 1;
    }

    return 0;
  });
}
const initialState = {
  isLoading: false,
  data: [],
  filteredProducts: [],
  currentPage: 1,
  productsPerPage: 6,
  error: null
};
const reducerFn = (state = initialState, action) => {
  switch (action.type) {
    case "IS_LOADING":
      return _objectSpread(_objectSpread({}, state), {}, {
        isLoading: action.payload
      });

    case "LOAD_PRODUCTS":
      const latestProducts = action.payload;
      return _objectSpread(_objectSpread({}, state), {}, {
        data: latestProducts,
        filteredProducts: latestProducts
      });

    case "FILTER_BY_CATEGORY":
      return _objectSpread(_objectSpread({}, state), {}, {
        filteredProducts: action.payload
      });

    case "FILTER_BY_PRICE":
      return _objectSpread(_objectSpread({}, state), {}, {
        filteredProducts: action.payload
      });

    case "SORT_BY_ALPHABETS":
      let results = action.payload.order === "asc" ? sortAsc(state.filteredProducts, "name") : sortDesc(state.filteredProducts, "name");
      return _objectSpread(_objectSpread({}, state), {}, {
        filteredProducts: results
      });

    case "SORT_BY_PRICE":
      let filteredProducts = action.payload.order === "asc" ? sortAsc(state.filteredProducts, "price") : sortDesc(state.filteredProducts, "price");
      return _objectSpread(_objectSpread({}, state), {}, {
        filteredProducts
      });

    case "SET_CURRENT_PAGE":
      return _objectSpread(_objectSpread({}, state), {}, {
        currentPage: action.payload
      });

    case "ERROR":
      return _objectSpread(_objectSpread({}, state), {}, {
        error: action.payload
      });

    default:
      return initialState;
  }
};
// CONCATENATED MODULE: ./context/Products/index.tsx


function Products_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Products_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Products_ownKeys(Object(source), true).forEach(function (key) { Products_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Products_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Products_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const ProductContext = /*#__PURE__*/Object(external_react_["createContext"])(undefined);

const ProductProvider = ({
  children
}) => {
  const {
    0: state,
    1: dispatch
  } = Object(external_react_["useReducer"])(reducerFn, initialState);
  const {
    filteredProducts,
    currentPage,
    productsPerPage
  } = state; // Get current posts

  const indexOfLastProduct = currentPage * productsPerPage;
  const indexOfFirstProduct = indexOfLastProduct - productsPerPage;
  const currentProducts = filteredProducts.slice(indexOfFirstProduct, indexOfLastProduct); // Change page

  const paginate = pageNumber => setCurrentPage(pageNumber);

  const nextPage = () => {
    dispatch({
      type: "SET_CURRENT_PAGE",
      payload: currentPage + 1
    });
  };

  const prevPage = () => {
    dispatch({
      type: "SET_CURRENT_PAGE",
      payload: currentPage > 1 ? currentPage - 1 : currentPage
    });
  };

  const setCurrentPage = pageNum => dispatch({
    type: "SET_CURRENT_PAGE",
    payload: pageNum
  });

  const sortByPrice = (order = "asc") => dispatch({
    type: "SORT_BY_PRICE",
    payload: {
      order: order
    }
  });

  const sortByAlphabets = (order = "asc") => dispatch({
    type: "SORT_BY_ALPHABETS",
    payload: {
      order
    }
  });

  const loadProducts = (products = []) => dispatch({
    type: "LOAD_PRODUCTS",
    payload: products
  });

  const filterByCategory = filters => {
    let result = [];
    filters.forEach(filter => {
      result = [...result, ...state.data.filter(product => product.category === filter)];
    });
    dispatch({
      type: "FILTER_BY_CATEGORY",
      payload: result.length ? result : state.data
    });
  };

  const filterByPrice = filters => {
    let result = [];
    filters.forEach(({
      min,
      max
    }) => {
      const min_price = Number(min);
      const max_price = Number(max);
      result = [...result, ...state.data.filter(product => product.price >= min_price && product.price <= max_price)];
    });
    dispatch({
      type: "FILTER_BY_PRICE",
      payload: result.length ? result : state.data
    });
  };

  const changeLoadingState = (loading = false) => dispatch({
    type: "IS_LOADING",
    payload: loading
  });

  let clearFilters = () => {};

  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(ProductContext.Provider, {
    value: Products_objectSpread(Products_objectSpread({}, state), {}, {
      changeLoadingState,
      loadProducts,
      clearFilters,
      sortByAlphabets,
      sortByPrice,
      filterByCategory,
      filterByPrice,
      paginate,
      nextPage,
      prevPage,
      currentPage,
      currentProducts,
      productsPerPage,
      totalProducts: filteredProducts.length
    }),
    children: children
  });
};

function useProductContext() {
  const context = Object(external_react_["useContext"])(ProductContext);

  if (context === undefined) {
    throw new Error("useProductContext must be used within a ProductProvider");
  }

  return context;
}


// CONCATENATED MODULE: ./context/Cart/index.tsx


function Cart_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Cart_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Cart_ownKeys(Object(source), true).forEach(function (key) { Cart_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Cart_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Cart_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const CartContext = /*#__PURE__*/Object(external_react_["createContext"])(undefined);
const Cart_initialState = {
  isOpen: false,
  cartItems: []
};

const Cart_reducerFn = (state = Cart_initialState, action) => {
  switch (action.type) {
    case "OPEN_CART":
      return Cart_objectSpread(Cart_objectSpread({}, state), {}, {
        isOpen: true
      });

    case "CLOSE_CART":
      return Cart_objectSpread(Cart_objectSpread({}, state), {}, {
        isOpen: false
      });

    case "ADD_TO_CART":
      const newProduct = action.payload;
      return Cart_objectSpread(Cart_objectSpread({}, state), {}, {
        cartItems: [...state.cartItems, newProduct]
      });

    case "CLEAR_CART":
      return Cart_initialState;

    default:
      return Cart_initialState;
  }
};

const CartProvider = ({
  children
}) => {
  const {
    0: state,
    1: dispatch
  } = Object(external_react_["useReducer"])(Cart_reducerFn, Cart_initialState);

  const addProductToCart = product => {
    const newCartItem = {
      id: Date.now(),
      product,
      quantity: 1,
      createdAt: new Date()
    };
    dispatch({
      type: "ADD_TO_CART",
      payload: newCartItem
    });
    !state.isOpen && openCart();
  };

  const clearCart = () => {
    dispatch({
      type: "CLEAR_CART"
    });
    closeCart();
  };

  const openCart = () => dispatch({
    type: "OPEN_CART"
  });

  const closeCart = () => dispatch({
    type: "CLOSE_CART"
  });

  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(CartContext.Provider, {
    value: {
      cart: state,
      addProductToCart,
      clearCart,
      openCart,
      closeCart
    },
    children: children
  });
};

function useCartContext() {
  const context = Object(external_react_["useContext"])(CartContext);

  if (context === undefined) {
    throw new Error("useCartContext must be used within a CartProvider");
  }

  return context;
}


// CONCATENATED MODULE: ./context/index.ts



/***/ }),

/***/ "5CT0":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"priceFilter": "priceFilter_priceFilter__TReEt"
};


/***/ }),

/***/ "5E+q":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"container": "layout_container__332Pr",
	"row": "layout_row__10dSq",
	"column": "layout_column__3o4FG",
	"addToCartBtn": "layout_addToCartBtn__13MqW",
	"cartCount": "layout_cartCount__3CQzq"
};


/***/ }),

/***/ "7UUK":
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/to-base-64.js");

/***/ }),

/***/ "8ep0":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"modal100w": "mobileFilter_modal100w__22V9X",
	"modalContent": "mobileFilter_modalContent__183B_",
	"modalBody": "mobileFilter_modalBody__3cn-U",
	"modalFooter": "mobileFilter_modalFooter__3CGZ9"
};


/***/ }),

/***/ "98FW":
/***/ (function(module, exports) {

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

module.exports = _objectWithoutPropertiesLoose;

/***/ }),

/***/ "ANQk":
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/server/image-config.js");

/***/ }),

/***/ "Aiso":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("dQHF")


/***/ }),

/***/ "AroE":
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "Dcqv":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"productSorter": "productSorter_productSorter__2c9jL",
	"orderSort": "productSorter_orderSort__1X3-9",
	"sortControls": "productSorter_sortControls__3gNAb",
	"asc": "productSorter_asc__3Wzho",
	"desc": "productSorter_desc__217-J"
};


/***/ }),

/***/ "F5FC":
/***/ (function(module, exports) {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "HcGf":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"featuredProduct": "featuredProduct_featuredProduct__2vB-G",
	"featured_img__wrapper": "featuredProduct_featured_img__wrapper__1iCW6",
	"photoOfDay": "featuredProduct_photoOfDay__hNifb",
	"addToCartBtn": "featuredProduct_addToCartBtn__3qoPK",
	"more_details": "featuredProduct_more_details__3e0wx",
	"description": "featuredProduct_description__2UuJn",
	"similar_products": "featuredProduct_similar_products__2VbyJ",
	"wrapper": "featuredProduct_wrapper__3o8db",
	"similar_product__img": "featuredProduct_similar_product__img__27_3E"
};


/***/ }),

/***/ "IZS3":
/***/ (function(module, exports) {

module.exports = require("react-bootstrap");

/***/ }),

/***/ "JR2A":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"pagination": "pagnation_pagination__wZV0T",
	"pageItem": "pagnation_pageItem__8Sdn6",
	"pagelink": "pagnation_pagelink__PLp9M",
	"active": "pagnation_active__19-H8"
};


/***/ }),

/***/ "TmFx":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"customBtn": "button_customBtn__2frKK"
};


/***/ }),

/***/ "UlpK":
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/head.js");

/***/ }),

/***/ "WbnN":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"cartItemWrapper": "cartItem_cartItemWrapper__3eQj2",
	"productDetails": "cartItem_productDetails__2IOoC",
	"name": "cartItem_name__3ZlOr",
	"price": "cartItem_price__1-sxB"
};


/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "dQHF":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__("AroE");

exports.__esModule = true;
exports.default = Image;

var _objectWithoutPropertiesLoose2 = _interopRequireDefault(__webpack_require__("98FW"));

var _extends2 = _interopRequireDefault(__webpack_require__("1ccW"));

var _react = _interopRequireDefault(__webpack_require__("cDcd"));

var _head = _interopRequireDefault(__webpack_require__("UlpK"));

var _toBase = __webpack_require__("7UUK");

var _imageConfig = __webpack_require__("ANQk");

var _useIntersection = __webpack_require__("vNVm");

if (true) {
  ;
  global.__NEXT_IMAGE_IMPORTED = true;
}

const VALID_LOADING_VALUES = ['lazy', 'eager', undefined];
const loaders = new Map([['imgix', imgixLoader], ['cloudinary', cloudinaryLoader], ['akamai', akamaiLoader], ['default', defaultLoader]]);
const VALID_LAYOUT_VALUES = ['fill', 'fixed', 'intrinsic', 'responsive', undefined];
const {
  deviceSizes: configDeviceSizes,
  imageSizes: configImageSizes,
  loader: configLoader,
  path: configPath,
  domains: configDomains
} = {"deviceSizes":[640,750,828,1080,1200,1920,2048,3840],"imageSizes":[16,32,48,64,96,128,256,384],"path":"https://images.pexels.com/","loader":"imgix"} || _imageConfig.imageConfigDefault; // sort smallest to largest

const allSizes = [...configDeviceSizes, ...configImageSizes];
configDeviceSizes.sort((a, b) => a - b);
allSizes.sort((a, b) => a - b);

function getWidths(width, layout, sizes) {
  if (sizes && (layout === 'fill' || layout === 'responsive')) {
    // Find all the "vw" percent sizes used in the sizes prop
    const percentSizes = [...sizes.matchAll(/(^|\s)(1?\d?\d)vw/g)].map(m => parseInt(m[2]));

    if (percentSizes.length) {
      const smallestRatio = Math.min(...percentSizes) * 0.01;
      return {
        widths: allSizes.filter(s => s >= configDeviceSizes[0] * smallestRatio),
        kind: 'w'
      };
    }

    return {
      widths: allSizes,
      kind: 'w'
    };
  }

  if (typeof width !== 'number' || layout === 'fill' || layout === 'responsive') {
    return {
      widths: configDeviceSizes,
      kind: 'w'
    };
  }

  const widths = [...new Set( // > This means that most OLED screens that say they are 3x resolution,
  // > are actually 3x in the green color, but only 1.5x in the red and
  // > blue colors. Showing a 3x resolution image in the app vs a 2x
  // > resolution image will be visually the same, though the 3x image
  // > takes significantly more data. Even true 3x resolution screens are
  // > wasteful as the human eye cannot see that level of detail without
  // > something like a magnifying glass.
  // https://blog.twitter.com/engineering/en_us/topics/infrastructure/2019/capping-image-fidelity-on-ultra-high-resolution-devices.html
  [width, width * 2
  /*, width * 3*/
  ].map(w => allSizes.find(p => p >= w) || allSizes[allSizes.length - 1]))];
  return {
    widths,
    kind: 'x'
  };
}

function generateImgAttrs({
  src,
  unoptimized,
  layout,
  width,
  quality,
  sizes,
  loader
}) {
  if (unoptimized) {
    return {
      src,
      srcSet: undefined,
      sizes: undefined
    };
  }

  const {
    widths,
    kind
  } = getWidths(width, layout, sizes);
  const last = widths.length - 1;
  return {
    sizes: !sizes && kind === 'w' ? '100vw' : sizes,
    srcSet: widths.map((w, i) => `${loader({
      src,
      quality,
      width: w
    })} ${kind === 'w' ? w : i + 1}${kind}`).join(', '),
    // It's intended to keep `src` the last attribute because React updates
    // attributes in order. If we keep `src` the first one, Safari will
    // immediately start to fetch `src`, before `sizes` and `srcSet` are even
    // updated by React. That causes multiple unnecessary requests if `srcSet`
    // and `sizes` are defined.
    // This bug cannot be reproduced in Chrome or Firefox.
    src: loader({
      src,
      quality,
      width: widths[last]
    })
  };
}

function getInt(x) {
  if (typeof x === 'number') {
    return x;
  }

  if (typeof x === 'string') {
    return parseInt(x, 10);
  }

  return undefined;
}

function defaultImageLoader(loaderProps) {
  const load = loaders.get(configLoader);

  if (load) {
    return load((0, _extends2.default)({
      root: configPath
    }, loaderProps));
  }

  throw new Error(`Unknown "loader" found in "next.config.js". Expected: ${_imageConfig.VALID_LOADERS.join(', ')}. Received: ${configLoader}`);
}

function Image(_ref) {
  let {
    src,
    sizes,
    unoptimized = false,
    priority = false,
    loading,
    className,
    quality,
    width,
    height,
    objectFit,
    objectPosition,
    loader = defaultImageLoader
  } = _ref,
      all = (0, _objectWithoutPropertiesLoose2.default)(_ref, ["src", "sizes", "unoptimized", "priority", "loading", "className", "quality", "width", "height", "objectFit", "objectPosition", "loader"]);
  let rest = all;
  let layout = sizes ? 'responsive' : 'intrinsic';
  let unsized = false;

  if ('unsized' in rest) {
    unsized = Boolean(rest.unsized); // Remove property so it's not spread into image:

    delete rest['unsized'];
  } else if ('layout' in rest) {
    // Override default layout if the user specified one:
    if (rest.layout) layout = rest.layout; // Remove property so it's not spread into image:

    delete rest['layout'];
  }

  if (false) {}

  let isLazy = !priority && (loading === 'lazy' || typeof loading === 'undefined');

  if (src && src.startsWith('data:')) {
    // https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/Data_URIs
    unoptimized = true;
    isLazy = false;
  }

  const [setRef, isIntersected] = (0, _useIntersection.useIntersection)({
    rootMargin: '200px',
    disabled: !isLazy
  });
  const isVisible = !isLazy || isIntersected;
  const widthInt = getInt(width);
  const heightInt = getInt(height);
  const qualityInt = getInt(quality);
  let wrapperStyle;
  let sizerStyle;
  let sizerSvg;
  let imgStyle = {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    boxSizing: 'border-box',
    padding: 0,
    border: 'none',
    margin: 'auto',
    display: 'block',
    width: 0,
    height: 0,
    minWidth: '100%',
    maxWidth: '100%',
    minHeight: '100%',
    maxHeight: '100%',
    objectFit,
    objectPosition
  };

  if (typeof widthInt !== 'undefined' && typeof heightInt !== 'undefined' && layout !== 'fill') {
    // <Image src="i.png" width="100" height="100" />
    const quotient = heightInt / widthInt;
    const paddingTop = isNaN(quotient) ? '100%' : `${quotient * 100}%`;

    if (layout === 'responsive') {
      // <Image src="i.png" width="100" height="100" layout="responsive" />
      wrapperStyle = {
        display: 'block',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        display: 'block',
        boxSizing: 'border-box',
        paddingTop
      };
    } else if (layout === 'intrinsic') {
      // <Image src="i.png" width="100" height="100" layout="intrinsic" />
      wrapperStyle = {
        display: 'inline-block',
        maxWidth: '100%',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        boxSizing: 'border-box',
        display: 'block',
        maxWidth: '100%'
      };
      sizerSvg = `<svg width="${widthInt}" height="${heightInt}" xmlns="http://www.w3.org/2000/svg" version="1.1"/>`;
    } else if (layout === 'fixed') {
      // <Image src="i.png" width="100" height="100" layout="fixed" />
      wrapperStyle = {
        overflow: 'hidden',
        boxSizing: 'border-box',
        display: 'inline-block',
        position: 'relative',
        width: widthInt,
        height: heightInt
      };
    }
  } else if (typeof widthInt === 'undefined' && typeof heightInt === 'undefined' && layout === 'fill') {
    // <Image src="i.png" layout="fill" />
    wrapperStyle = {
      display: 'block',
      overflow: 'hidden',
      position: 'absolute',
      top: 0,
      left: 0,
      bottom: 0,
      right: 0,
      boxSizing: 'border-box',
      margin: 0
    };
  } else {
    // <Image src="i.png" />
    if (false) {}
  }

  let imgAttributes = {
    src: 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
    srcSet: undefined,
    sizes: undefined
  };

  if (isVisible) {
    imgAttributes = generateImgAttrs({
      src,
      unoptimized,
      layout,
      width: widthInt,
      quality: qualityInt,
      sizes,
      loader
    });
  }

  if (unsized) {
    wrapperStyle = undefined;
    sizerStyle = undefined;
    imgStyle = undefined;
  }

  return /*#__PURE__*/_react.default.createElement("div", {
    style: wrapperStyle
  }, sizerStyle ? /*#__PURE__*/_react.default.createElement("div", {
    style: sizerStyle
  }, sizerSvg ? /*#__PURE__*/_react.default.createElement("img", {
    style: {
      maxWidth: '100%',
      display: 'block',
      margin: 0,
      border: 'none',
      padding: 0
    },
    alt: "",
    "aria-hidden": true,
    role: "presentation",
    src: `data:image/svg+xml;base64,${(0, _toBase.toBase64)(sizerSvg)}`
  }) : null) : null, !isVisible && /*#__PURE__*/_react.default.createElement("noscript", null, /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, generateImgAttrs({
    src,
    unoptimized,
    layout,
    width: widthInt,
    quality: qualityInt,
    sizes,
    loader
  }), {
    src: src,
    decoding: "async",
    sizes: sizes,
    style: imgStyle,
    className: className
  }))), /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, imgAttributes, {
    decoding: "async",
    className: className,
    ref: setRef,
    style: imgStyle
  })), priority ?
  /*#__PURE__*/
  // Note how we omit the `href` attribute, as it would only be relevant
  // for browsers that do not support `imagesrcset`, and in those cases
  // it would likely cause the incorrect image to be preloaded.
  //
  // https://html.spec.whatwg.org/multipage/semantics.html#attr-link-imagesrcset
  _react.default.createElement(_head.default, null, /*#__PURE__*/_react.default.createElement("link", {
    key: '__nimg-' + imgAttributes.src + imgAttributes.srcSet + imgAttributes.sizes,
    rel: "preload",
    as: "image",
    href: imgAttributes.srcSet ? undefined : imgAttributes.src // @ts-ignore: imagesrcset is not yet in the link element type
    ,
    imagesrcset: imgAttributes.srcSet // @ts-ignore: imagesizes is not yet in the link element type
    ,
    imagesizes: imgAttributes.sizes
  })) : null);
} //BUILT IN LOADERS


function normalizeSrc(src) {
  return src[0] === '/' ? src.slice(1) : src;
}

function imgixLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://static.imgix.net/daisy.png?format=auto&fit=max&w=300
  const params = ['auto=format', 'fit=max', 'w=' + width];
  let paramsString = '';

  if (quality) {
    params.push('q=' + quality);
  }

  if (params.length) {
    paramsString = '?' + params.join('&');
  }

  return `${root}${normalizeSrc(src)}${paramsString}`;
}

function akamaiLoader({
  root,
  src,
  width
}) {
  return `${root}${normalizeSrc(src)}?imwidth=${width}`;
}

function cloudinaryLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://res.cloudinary.com/demo/image/upload/w_300,c_limit,q_auto/turtles.jpg
  const params = ['f_auto', 'c_limit', 'w_' + width, 'q_' + (quality || 'auto')];
  let paramsString = params.join(',') + '/';
  return `${root}${paramsString}${normalizeSrc(src)}`;
}

function defaultLoader({
  root,
  src,
  width,
  quality
}) {
  if (false) {}

  return `${root}?url=${encodeURIComponent(src)}&w=${width}&q=${quality || 75}`;
}

/***/ }),

/***/ "gLdB":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"loader": "loader_loader__8hNi6",
	"spinner": "loader_spinner__39TiC",
	"spin": "loader_spin__2-ti_"
};


/***/ }),

/***/ "krTd":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"productSection": "productSection_productSection__365hl",
	"category": "productSection_category__2quGF",
	"filterToggle": "productSection_filterToggle__1HQQH",
	"productWrapper": "productSection_productWrapper__2nBn1"
};


/***/ }),

/***/ "mMNo":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"productList": "productList_productList__3rlgL"
};


/***/ }),

/***/ "pNaP":
/***/ (function(module, exports) {

module.exports = require("firebase");

/***/ }),

/***/ "pXDl":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"productFilter": "productFilter_productFilter__2pET-",
	"categoryFilter": "productFilter_categoryFilter__JoThK",
	"priceFilter": "productFilter_priceFilter__1HB0C"
};


/***/ }),

/***/ "pk4n":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"categoryFilter": "categoryFilter_categoryFilter__1CBU4"
};


/***/ }),

/***/ "rDcf":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"productItem": "product_productItem__3Zu4E",
	"wrapper": "product_wrapper__az_me",
	"productCover": "product_productCover__14DHa",
	"bestSellerFlag": "product_bestSellerFlag__1AMpA",
	"addToCart": "product_addToCart__1g78Y",
	"productTag": "product_productTag__16l81",
	"productName": "product_productName__2nW01",
	"productPrice": "product_productPrice__p3wcY"
};


/***/ }),

/***/ "sQGF":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return db; });
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("pNaP");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_0__);

const config = {
  apiKey: "AIzaSyBMZj-_kOItk2OYKtDHZSeeqvOMN5JUX0E",
  authDomain: "naijafries-21386.firebaseapp.com",
  projectId: "naijafries-21386"
};

if (!firebase__WEBPACK_IMPORTED_MODULE_0___default.a.apps.length) {
  try {
    firebase__WEBPACK_IMPORTED_MODULE_0___default.a.initializeApp(config);
  } catch (error) {
    console.log("Firebase admin initialization error", error.stack);
  }
}

const db = firebase__WEBPACK_IMPORTED_MODULE_0___default.a.firestore();


/***/ }),

/***/ "vNVm":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.useIntersection = useIntersection;

var _react = __webpack_require__("cDcd");

var _requestIdleCallback = __webpack_require__("0G5g");

const hasIntersectionObserver = typeof IntersectionObserver !== 'undefined';

function useIntersection({
  rootMargin,
  disabled
}) {
  const isDisabled = disabled || !hasIntersectionObserver;
  const unobserve = (0, _react.useRef)();
  const [visible, setVisible] = (0, _react.useState)(false);
  const setRef = (0, _react.useCallback)(el => {
    if (unobserve.current) {
      unobserve.current();
      unobserve.current = undefined;
    }

    if (isDisabled || visible) return;

    if (el && el.tagName) {
      unobserve.current = observe(el, isVisible => isVisible && setVisible(isVisible), {
        rootMargin
      });
    }
  }, [isDisabled, rootMargin, visible]);
  (0, _react.useEffect)(() => {
    if (!hasIntersectionObserver) {
      if (!visible) {
        const idleCallback = (0, _requestIdleCallback.requestIdleCallback)(() => setVisible(true));
        return () => (0, _requestIdleCallback.cancelIdleCallback)(idleCallback);
      }
    }
  }, [visible]);
  return [setRef, visible];
}

function observe(element, callback, options) {
  const {
    id,
    observer,
    elements
  } = createObserver(options);
  elements.set(element, callback);
  observer.observe(element);
  return function unobserve() {
    elements.delete(element);
    observer.unobserve(element); // Destroy observer when there's nothing left to watch:

    if (elements.size === 0) {
      observer.disconnect();
      observers.delete(id);
    }
  };
}

const observers = new Map();

function createObserver(options) {
  const id = options.rootMargin || '';
  let instance = observers.get(id);

  if (instance) {
    return instance;
  }

  const elements = new Map();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const callback = elements.get(entry.target);
      const isVisible = entry.isIntersecting || entry.intersectionRatio > 0;

      if (callback && isVisible) {
        callback(isVisible);
      }
    });
  }, options);
  observers.set(id, instance = {
    id,
    observer,
    elements
  });
  return instance;
}

/***/ }),

/***/ "xnum":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ })

/******/ });