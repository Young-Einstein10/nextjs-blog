webpackHotUpdate_N_E("pages/index",{

/***/ "./components/Pagination/index.tsx":
/*!*****************************************!*\
  !*** ./components/Pagination/index.tsx ***!
  \*****************************************/
/*! exports provided: Pagination */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Pagination", function() { return Pagination; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../context */ "./context/index.ts");
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Button */ "./components/Button/index.tsx");
/* harmony import */ var _SVGs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../SVGs */ "./components/SVGs/index.ts");
/* harmony import */ var _pagnation_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pagnation.module.scss */ "./components/Pagination/pagnation.module.scss");
/* harmony import */ var _pagnation_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_pagnation_module_scss__WEBPACK_IMPORTED_MODULE_5__);


var _jsxFileName = "C:\\Users\\Owner\\Desktop\\nextjs-blog\\components\\Pagination\\index.tsx",
    _this = undefined,
    _s = $RefreshSig$();






var Pagination = function Pagination(props) {
  _s();

  var _useProductContext = Object(_context__WEBPACK_IMPORTED_MODULE_2__["useProductContext"])(),
      productsPerPage = _useProductContext.productsPerPage,
      totalProducts = _useProductContext.totalProducts,
      paginate = _useProductContext.paginate,
      currentPage = _useProductContext.currentPage,
      nextPage = _useProductContext.nextPage,
      prevPage = _useProductContext.prevPage;

  var pagination = _pagnation_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.pagination,
      pageItem = _pagnation_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.pageItem,
      pagelink = _pagnation_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.pagelink,
      active = _pagnation_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.active;
  var pageNumbers = [];

  for (var i = 1; i <= Math.ceil(totalProducts / productsPerPage); i++) {
    pageNumbers.push(i);
  }

  var lastPage = pageNumbers[pageNumbers.length - 1];
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("footer", {
    className: "mt-3 mb-5 d-flex justify-content-center align-items-center",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ul", {
      className: "".concat(pagination, " pagination"),
      children: [currentPage > 1 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Button__WEBPACK_IMPORTED_MODULE_3__["Button"], {
        onClick: function onClick() {
          return prevPage();
        },
        className: "mr-2",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_SVGs__WEBPACK_IMPORTED_MODULE_4__["AngleLeft"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 39,
          columnNumber: 13
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 11
      }, _this), pageNumbers.map(function (number) {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("li", {
          className: "".concat(pageItem, " page-item"),
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            onClick: function onClick(e) {
              e.preventDefault();
              paginate(number);
            },
            href: "!#",
            className: "".concat(pagelink, " ").concat(currentPage === number && active, " page-link"),
            children: number
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 45,
            columnNumber: 13
          }, _this)
        }, number, false, {
          fileName: _jsxFileName,
          lineNumber: 44,
          columnNumber: 11
        }, _this);
      }), currentPage !== lastPage && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Button__WEBPACK_IMPORTED_MODULE_3__["Button"], {
        onClick: function onClick() {
          return nextPage();
        },
        className: "ml-2",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_SVGs__WEBPACK_IMPORTED_MODULE_4__["AngleRight"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 59,
          columnNumber: 13
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 11
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 36,
      columnNumber: 7
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 35,
    columnNumber: 5
  }, _this);
};

_s(Pagination, "ZM7hg7sQg2BWbLDfjDEEIwB4nM0=", false, function () {
  return [_context__WEBPACK_IMPORTED_MODULE_2__["useProductContext"]];
});

_c = Pagination;

var _c;

$RefreshReg$(_c, "Pagination");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ }),

/***/ "./components/ProductSection/index.tsx":
/*!*********************************************!*\
  !*** ./components/ProductSection/index.tsx ***!
  \*********************************************/
/*! exports provided: ProductSection */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductSection", function() { return ProductSection; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ProductSorter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../ProductSorter */ "./components/ProductSorter/index.tsx");
/* harmony import */ var _ProductFilter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../ProductFilter */ "./components/ProductFilter/index.tsx");
/* harmony import */ var _ProductList__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../ProductList */ "./components/ProductList/index.tsx");
/* harmony import */ var _SVGs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../SVGs */ "./components/SVGs/index.ts");
/* harmony import */ var _productSection_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./productSection.module.scss */ "./components/ProductSection/productSection.module.scss");
/* harmony import */ var _productSection_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_productSection_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _MobileFilter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../MobileFilter */ "./components/MobileFilter/index.tsx");
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../Button */ "./components/Button/index.tsx");


var _jsxFileName = "C:\\Users\\Owner\\Desktop\\nextjs-blog\\components\\ProductSection\\index.tsx",
    _this = undefined,
    _s = $RefreshSig$();









var ProductSection = function ProductSection() {
  _s();

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false),
      isMobileFilterOpen = _useState[0],
      setIsMobileFilterOpen = _useState[1];

  var productSection = _productSection_module_scss__WEBPACK_IMPORTED_MODULE_6___default.a.productSection,
      productWrapper = _productSection_module_scss__WEBPACK_IMPORTED_MODULE_6___default.a.productWrapper,
      category = _productSection_module_scss__WEBPACK_IMPORTED_MODULE_6___default.a.category,
      filterToggle = _productSection_module_scss__WEBPACK_IMPORTED_MODULE_6___default.a.filterToggle;

  var toggleFilterModal = function toggleFilterModal() {
    return setIsMobileFilterOpen(function (open) {
      return !open;
    });
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("section", {
    className: "".concat(productSection, " mt-5"),
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("header", {
      className: "d-flex align-items-center justify-content-between",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "".concat(category, " d-flex align-items-center flex-wrap"),
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("strong", {
            children: "Photography"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 24,
            columnNumber: 13
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 23,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("strong", {
            className: "mx-md-4",
            children: "/"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 27,
            columnNumber: 13
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 26,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          children: "Premium Photos"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 30,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ProductSorter__WEBPACK_IMPORTED_MODULE_2__["ProductSorter"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 33,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Button__WEBPACK_IMPORTED_MODULE_8__["Button"], {
        onClick: function onClick() {
          return toggleFilterModal();
        },
        className: filterToggle,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_SVGs__WEBPACK_IMPORTED_MODULE_5__["FilterToggle"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 36,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 21,
      columnNumber: 7
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "".concat(productWrapper, " d-flex"),
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ProductFilter__WEBPACK_IMPORTED_MODULE_3__["ProductFilter"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ProductList__WEBPACK_IMPORTED_MODULE_4__["ProductList"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 9
      }, _this), isMobileFilterOpen ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_MobileFilter__WEBPACK_IMPORTED_MODULE_7__["MobileFilter"], {
        isOpen: isMobileFilterOpen,
        toggleFilterModal: toggleFilterModal
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 11
      }, _this) : null]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 20,
    columnNumber: 5
  }, _this);
};

_s(ProductSection, "0PWc+RLa/0sKGH8jCxmm/6dK7VY=");

_c = ProductSection;

var _c;

$RefreshReg$(_c, "ProductSection");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9QYWdpbmF0aW9uL2luZGV4LnRzeCIsIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9Qcm9kdWN0U2VjdGlvbi9pbmRleC50c3giXSwibmFtZXMiOlsiUGFnaW5hdGlvbiIsInByb3BzIiwidXNlUHJvZHVjdENvbnRleHQiLCJwcm9kdWN0c1BlclBhZ2UiLCJ0b3RhbFByb2R1Y3RzIiwicGFnaW5hdGUiLCJjdXJyZW50UGFnZSIsIm5leHRQYWdlIiwicHJldlBhZ2UiLCJwYWdpbmF0aW9uIiwic3R5bGVzIiwicGFnZUl0ZW0iLCJwYWdlbGluayIsImFjdGl2ZSIsInBhZ2VOdW1iZXJzIiwiaSIsIk1hdGgiLCJjZWlsIiwicHVzaCIsImxhc3RQYWdlIiwibGVuZ3RoIiwibWFwIiwibnVtYmVyIiwiZSIsInByZXZlbnREZWZhdWx0IiwiUHJvZHVjdFNlY3Rpb24iLCJ1c2VTdGF0ZSIsImlzTW9iaWxlRmlsdGVyT3BlbiIsInNldElzTW9iaWxlRmlsdGVyT3BlbiIsInByb2R1Y3RTZWN0aW9uIiwicHJvZHVjdFdyYXBwZXIiLCJjYXRlZ29yeSIsImZpbHRlclRvZ2dsZSIsInRvZ2dsZUZpbHRlck1vZGFsIiwib3BlbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQVFPLElBQU1BLFVBQWMsR0FBRyxTQUFqQkEsVUFBaUIsQ0FBQ0MsS0FBRCxFQUFXO0FBQUE7O0FBQUEsMkJBUW5DQyxrRUFBaUIsRUFSa0I7QUFBQSxNQUVyQ0MsZUFGcUMsc0JBRXJDQSxlQUZxQztBQUFBLE1BR3JDQyxhQUhxQyxzQkFHckNBLGFBSHFDO0FBQUEsTUFJckNDLFFBSnFDLHNCQUlyQ0EsUUFKcUM7QUFBQSxNQUtyQ0MsV0FMcUMsc0JBS3JDQSxXQUxxQztBQUFBLE1BTXJDQyxRQU5xQyxzQkFNckNBLFFBTnFDO0FBQUEsTUFPckNDLFFBUHFDLHNCQU9yQ0EsUUFQcUM7O0FBQUEsTUFVL0JDLFVBVitCLEdBVVlDLDZEQVZaLENBVS9CRCxVQVYrQjtBQUFBLE1BVW5CRSxRQVZtQixHQVVZRCw2REFWWixDQVVuQkMsUUFWbUI7QUFBQSxNQVVUQyxRQVZTLEdBVVlGLDZEQVZaLENBVVRFLFFBVlM7QUFBQSxNQVVDQyxNQVZELEdBVVlILDZEQVZaLENBVUNHLE1BVkQ7QUFZdkMsTUFBTUMsV0FBVyxHQUFHLEVBQXBCOztBQUVBLE9BQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsSUFBSUMsSUFBSSxDQUFDQyxJQUFMLENBQVViLGFBQWEsR0FBR0QsZUFBMUIsQ0FBckIsRUFBaUVZLENBQUMsRUFBbEUsRUFBc0U7QUFDcEVELGVBQVcsQ0FBQ0ksSUFBWixDQUFpQkgsQ0FBakI7QUFDRDs7QUFFRCxNQUFNSSxRQUFRLEdBQUdMLFdBQVcsQ0FBQ0EsV0FBVyxDQUFDTSxNQUFaLEdBQXFCLENBQXRCLENBQTVCO0FBRUEsc0JBQ0U7QUFBUSxhQUFTLEVBQUMsNERBQWxCO0FBQUEsMkJBQ0U7QUFBSSxlQUFTLFlBQUtYLFVBQUwsZ0JBQWI7QUFBQSxpQkFDR0gsV0FBVyxHQUFHLENBQWQsaUJBQ0MscUVBQUMsOENBQUQ7QUFBUSxlQUFPLEVBQUU7QUFBQSxpQkFBTUUsUUFBUSxFQUFkO0FBQUEsU0FBakI7QUFBbUMsaUJBQVMsRUFBQyxNQUE3QztBQUFBLCtCQUNFLHFFQUFDLCtDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRkosRUFPR00sV0FBVyxDQUFDTyxHQUFaLENBQWdCLFVBQUNDLE1BQUQ7QUFBQSw0QkFDZjtBQUFpQixtQkFBUyxZQUFLWCxRQUFMLGVBQTFCO0FBQUEsaUNBQ0U7QUFDRSxtQkFBTyxFQUFFLGlCQUFDWSxDQUFELEVBQU87QUFDZEEsZUFBQyxDQUFDQyxjQUFGO0FBQ0FuQixzQkFBUSxDQUFDaUIsTUFBRCxDQUFSO0FBQ0QsYUFKSDtBQUtFLGdCQUFJLEVBQUMsSUFMUDtBQU1FLHFCQUFTLFlBQUtWLFFBQUwsY0FBaUJOLFdBQVcsS0FBS2dCLE1BQWhCLElBQTBCVCxNQUEzQyxlQU5YO0FBQUEsc0JBT0dTO0FBUEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLFdBQVNBLE1BQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFEZTtBQUFBLE9BQWhCLENBUEgsRUFxQkdoQixXQUFXLEtBQUthLFFBQWhCLGlCQUNDLHFFQUFDLDhDQUFEO0FBQVEsZUFBTyxFQUFFO0FBQUEsaUJBQU1aLFFBQVEsRUFBZDtBQUFBLFNBQWpCO0FBQW1DLGlCQUFTLEVBQUMsTUFBN0M7QUFBQSwrQkFDRSxxRUFBQyxnREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUErQkQsQ0FuRE07O0dBQU1QLFU7VUFRUEUsMEQ7OztLQVJPRixVOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNiYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFFQTtBQUNBO0FBRU8sSUFBTXlCLGNBQWtCLEdBQUcsU0FBckJBLGNBQXFCLEdBQU07QUFBQTs7QUFBQSxrQkFDY0Msc0RBQVEsQ0FBQyxLQUFELENBRHRCO0FBQUEsTUFDL0JDLGtCQUQrQjtBQUFBLE1BQ1hDLHFCQURXOztBQUFBLE1BRzlCQyxjQUg4QixHQUc2Qm5CLGtFQUg3QixDQUc5Qm1CLGNBSDhCO0FBQUEsTUFHZEMsY0FIYyxHQUc2QnBCLGtFQUg3QixDQUdkb0IsY0FIYztBQUFBLE1BR0VDLFFBSEYsR0FHNkJyQixrRUFIN0IsQ0FHRXFCLFFBSEY7QUFBQSxNQUdZQyxZQUhaLEdBRzZCdEIsa0VBSDdCLENBR1lzQixZQUhaOztBQUt0QyxNQUFNQyxpQkFBaUIsR0FBRyxTQUFwQkEsaUJBQW9CO0FBQUEsV0FBTUwscUJBQXFCLENBQUMsVUFBQ00sSUFBRDtBQUFBLGFBQVUsQ0FBQ0EsSUFBWDtBQUFBLEtBQUQsQ0FBM0I7QUFBQSxHQUExQjs7QUFFQSxzQkFDRTtBQUFTLGFBQVMsWUFBS0wsY0FBTCxVQUFsQjtBQUFBLDRCQUNFO0FBQVEsZUFBUyxFQUFDLG1EQUFsQjtBQUFBLDhCQUNFO0FBQUssaUJBQVMsWUFBS0UsUUFBTCx5Q0FBZDtBQUFBLGdDQUNFO0FBQUEsaUNBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBSUU7QUFBQSxpQ0FDRTtBQUFRLHFCQUFTLEVBQUMsU0FBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUpGLGVBUUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREYsZUFZRSxxRUFBQyw0REFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWkYsZUFjRSxxRUFBQyw4Q0FBRDtBQUFRLGVBQU8sRUFBRTtBQUFBLGlCQUFNRSxpQkFBaUIsRUFBdkI7QUFBQSxTQUFqQjtBQUE0QyxpQkFBUyxFQUFFRCxZQUF2RDtBQUFBLCtCQUNFLHFFQUFDLGtEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREYsZUFvQkU7QUFBSyxlQUFTLFlBQUtGLGNBQUwsWUFBZDtBQUFBLDhCQUNFLHFFQUFDLDREQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERixlQUdFLHFFQUFDLHdEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFIRixFQUtHSCxrQkFBa0IsZ0JBQ2pCLHFFQUFDLDBEQUFEO0FBQWMsY0FBTSxFQUFFQSxrQkFBdEI7QUFBMEMseUJBQWlCLEVBQUVNO0FBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFEaUIsR0FFZixJQVBOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FERjtBQWdDRCxDQXZDTTs7R0FBTVIsYzs7S0FBQUEsYyIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC4wNWQ4Yzc4ODMxMDBmNWZmYWY3Yi5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IEZDIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZVByb2R1Y3RDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2NvbnRleHRcIjtcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIi4uL0J1dHRvblwiO1xyXG5pbXBvcnQgeyBBbmdsZVJpZ2h0LCBBbmdsZUxlZnQgfSBmcm9tIFwiLi4vU1ZHc1wiO1xyXG5cclxuaW1wb3J0IHN0eWxlcyBmcm9tIFwiLi9wYWduYXRpb24ubW9kdWxlLnNjc3NcIjtcclxuXHJcbmludGVyZmFjZSBJUGFnaW5hdGlvblByb3BzIHtcclxuICBwb3N0c1BlclBhZ2U6IG51bWJlcjtcclxuICB0b3RhbFBvc3RzOiBudW1iZXI7XHJcbiAgcGFnaW5hdGU6IChudW1iZXI6IG51bWJlcikgPT4gdm9pZDtcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IFBhZ2luYXRpb246IEZDID0gKHByb3BzKSA9PiB7XHJcbiAgY29uc3Qge1xyXG4gICAgcHJvZHVjdHNQZXJQYWdlLFxyXG4gICAgdG90YWxQcm9kdWN0cyxcclxuICAgIHBhZ2luYXRlLFxyXG4gICAgY3VycmVudFBhZ2UsXHJcbiAgICBuZXh0UGFnZSxcclxuICAgIHByZXZQYWdlLFxyXG4gIH0gPSB1c2VQcm9kdWN0Q29udGV4dCgpO1xyXG5cclxuICBjb25zdCB7IHBhZ2luYXRpb24sIHBhZ2VJdGVtLCBwYWdlbGluaywgYWN0aXZlIH0gPSBzdHlsZXM7XHJcblxyXG4gIGNvbnN0IHBhZ2VOdW1iZXJzID0gW107XHJcblxyXG4gIGZvciAobGV0IGkgPSAxOyBpIDw9IE1hdGguY2VpbCh0b3RhbFByb2R1Y3RzIC8gcHJvZHVjdHNQZXJQYWdlKTsgaSsrKSB7XHJcbiAgICBwYWdlTnVtYmVycy5wdXNoKGkpO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgbGFzdFBhZ2UgPSBwYWdlTnVtYmVyc1twYWdlTnVtYmVycy5sZW5ndGggLSAxXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxmb290ZXIgY2xhc3NOYW1lPVwibXQtMyBtYi01IGQtZmxleCBqdXN0aWZ5LWNvbnRlbnQtY2VudGVyIGFsaWduLWl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICA8dWwgY2xhc3NOYW1lPXtgJHtwYWdpbmF0aW9ufSBwYWdpbmF0aW9uYH0+XHJcbiAgICAgICAge2N1cnJlbnRQYWdlID4gMSAmJiAoXHJcbiAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9eygpID0+IHByZXZQYWdlKCl9IGNsYXNzTmFtZT1cIm1yLTJcIj5cclxuICAgICAgICAgICAgPEFuZ2xlTGVmdCAvPlxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgKX1cclxuXHJcbiAgICAgICAge3BhZ2VOdW1iZXJzLm1hcCgobnVtYmVyKSA9PiAoXHJcbiAgICAgICAgICA8bGkga2V5PXtudW1iZXJ9IGNsYXNzTmFtZT17YCR7cGFnZUl0ZW19IHBhZ2UtaXRlbWB9PlxyXG4gICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgICAgICBwYWdpbmF0ZShudW1iZXIpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgaHJlZj1cIiEjXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2Ake3BhZ2VsaW5rfSAke2N1cnJlbnRQYWdlID09PSBudW1iZXIgJiYgYWN0aXZlfSBwYWdlLWxpbmtgfT5cclxuICAgICAgICAgICAgICB7bnVtYmVyfVxyXG4gICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICkpfVxyXG5cclxuICAgICAgICB7Y3VycmVudFBhZ2UgIT09IGxhc3RQYWdlICYmIChcclxuICAgICAgICAgIDxCdXR0b24gb25DbGljaz17KCkgPT4gbmV4dFBhZ2UoKX0gY2xhc3NOYW1lPVwibWwtMlwiPlxyXG4gICAgICAgICAgICA8QW5nbGVSaWdodCAvPlxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC91bD5cclxuICAgIDwvZm9vdGVyPlxyXG4gICk7XHJcbn07XHJcbiIsImltcG9ydCBSZWFjdCwgeyBGQywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgUHJvZHVjdFNvcnRlciB9IGZyb20gXCIuLi9Qcm9kdWN0U29ydGVyXCI7XHJcbmltcG9ydCB7IFByb2R1Y3RGaWx0ZXIgfSBmcm9tIFwiLi4vUHJvZHVjdEZpbHRlclwiO1xyXG5pbXBvcnQgeyBQcm9kdWN0TGlzdCB9IGZyb20gXCIuLi9Qcm9kdWN0TGlzdFwiO1xyXG5pbXBvcnQgeyBGaWx0ZXJUb2dnbGUgfSBmcm9tIFwiLi4vU1ZHc1wiO1xyXG5cclxuaW1wb3J0IHN0eWxlcyBmcm9tIFwiLi9wcm9kdWN0U2VjdGlvbi5tb2R1bGUuc2Nzc1wiO1xyXG5pbXBvcnQgeyB1c2VQcm9kdWN0Q29udGV4dCB9IGZyb20gXCIuLi8uLi9jb250ZXh0XCI7XHJcbmltcG9ydCB7IE1vYmlsZUZpbHRlciB9IGZyb20gXCIuLi9Nb2JpbGVGaWx0ZXJcIjtcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIi4uL0J1dHRvblwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IFByb2R1Y3RTZWN0aW9uOiBGQyA9ICgpID0+IHtcclxuICBjb25zdCBbaXNNb2JpbGVGaWx0ZXJPcGVuLCBzZXRJc01vYmlsZUZpbHRlck9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCB7IHByb2R1Y3RTZWN0aW9uLCBwcm9kdWN0V3JhcHBlciwgY2F0ZWdvcnksIGZpbHRlclRvZ2dsZSB9ID0gc3R5bGVzO1xyXG5cclxuICBjb25zdCB0b2dnbGVGaWx0ZXJNb2RhbCA9ICgpID0+IHNldElzTW9iaWxlRmlsdGVyT3Blbigob3BlbikgPT4gIW9wZW4pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPXtgJHtwcm9kdWN0U2VjdGlvbn0gbXQtNWB9PlxyXG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXIganVzdGlmeS1jb250ZW50LWJldHdlZW5cIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YCR7Y2F0ZWdvcnl9IGQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXIgZmxleC13cmFwYH0+XHJcbiAgICAgICAgICA8cD5cclxuICAgICAgICAgICAgPHN0cm9uZz5QaG90b2dyYXBoeTwvc3Ryb25nPlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwibXgtbWQtNFwiPi88L3N0cm9uZz5cclxuICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICA8cD5QcmVtaXVtIFBob3RvczwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPFByb2R1Y3RTb3J0ZXIgLz5cclxuXHJcbiAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB0b2dnbGVGaWx0ZXJNb2RhbCgpfSBjbGFzc05hbWU9e2ZpbHRlclRvZ2dsZX0+XHJcbiAgICAgICAgICA8RmlsdGVyVG9nZ2xlIC8+XHJcbiAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgIDwvaGVhZGVyPlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9e2Ake3Byb2R1Y3RXcmFwcGVyfSBkLWZsZXhgfT5cclxuICAgICAgICA8UHJvZHVjdEZpbHRlciAvPlxyXG5cclxuICAgICAgICA8UHJvZHVjdExpc3QgLz5cclxuXHJcbiAgICAgICAge2lzTW9iaWxlRmlsdGVyT3BlbiA/IChcclxuICAgICAgICAgIDxNb2JpbGVGaWx0ZXIgaXNPcGVuPXtpc01vYmlsZUZpbHRlck9wZW59IHRvZ2dsZUZpbHRlck1vZGFsPXt0b2dnbGVGaWx0ZXJNb2RhbH0gLz5cclxuICAgICAgICApIDogbnVsbH1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufTtcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==