module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cha2");


/***/ }),

/***/ "4rth":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "b", function() { return /* reexport */ ProductProvider; });
__webpack_require__.d(__webpack_exports__, "d", function() { return /* reexport */ useProductContext; });
__webpack_require__.d(__webpack_exports__, "a", function() { return /* reexport */ CartProvider; });
__webpack_require__.d(__webpack_exports__, "c", function() { return /* reexport */ useCartContext; });

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");

// CONCATENATED MODULE: ./context/Products/helpers.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function sortAsc(arr, field) {
  return arr.sort(function (a, b) {
    if (a[field] > b[field]) {
      return 1;
    }

    if (b[field] > a[field]) {
      return -1;
    }

    return 0;
  });
}
function sortDesc(arr, field) {
  return arr.sort(function (a, b) {
    if (a[field] > b[field]) {
      return -1;
    }

    if (b[field] > a[field]) {
      return 1;
    }

    return 0;
  });
}
const initialState = {
  isLoading: false,
  data: [],
  filteredProducts: [],
  currentPage: 1,
  productsPerPage: 6,
  error: null
};
const reducerFn = (state = initialState, action) => {
  switch (action.type) {
    case "IS_LOADING":
      return _objectSpread(_objectSpread({}, state), {}, {
        isLoading: action.payload
      });

    case "LOAD_PRODUCTS":
      const latestProducts = action.payload;
      return _objectSpread(_objectSpread({}, state), {}, {
        data: latestProducts,
        filteredProducts: latestProducts
      });

    case "FILTER_BY_CATEGORY":
      return _objectSpread(_objectSpread({}, state), {}, {
        filteredProducts: action.payload
      });

    case "FILTER_BY_PRICE":
      return _objectSpread(_objectSpread({}, state), {}, {
        filteredProducts: action.payload
      });

    case "SORT_BY_ALPHABETS":
      let results = action.payload.order === "asc" ? sortAsc(state.filteredProducts, "name") : sortDesc(state.filteredProducts, "name");
      return _objectSpread(_objectSpread({}, state), {}, {
        filteredProducts: results
      });

    case "SORT_BY_PRICE":
      let filteredProducts = action.payload.order === "asc" ? sortAsc(state.filteredProducts, "price") : sortDesc(state.filteredProducts, "price");
      return _objectSpread(_objectSpread({}, state), {}, {
        filteredProducts
      });

    case "SET_CURRENT_PAGE":
      return _objectSpread(_objectSpread({}, state), {}, {
        currentPage: action.payload
      });

    case "ERROR":
      return _objectSpread(_objectSpread({}, state), {}, {
        error: action.payload
      });

    default:
      return initialState;
  }
};
// CONCATENATED MODULE: ./context/Products/index.tsx


function Products_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Products_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Products_ownKeys(Object(source), true).forEach(function (key) { Products_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Products_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Products_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const ProductContext = /*#__PURE__*/Object(external_react_["createContext"])(undefined);

const ProductProvider = ({
  children
}) => {
  const {
    0: state,
    1: dispatch
  } = Object(external_react_["useReducer"])(reducerFn, initialState);
  const {
    filteredProducts,
    currentPage,
    productsPerPage
  } = state; // Get current posts

  const indexOfLastProduct = currentPage * productsPerPage;
  const indexOfFirstProduct = indexOfLastProduct - productsPerPage;
  const currentProducts = filteredProducts.slice(indexOfFirstProduct, indexOfLastProduct); // Change page

  const paginate = pageNumber => setCurrentPage(pageNumber);

  const nextPage = () => {
    dispatch({
      type: "SET_CURRENT_PAGE",
      payload: currentPage + 1
    });
  };

  const prevPage = () => {
    dispatch({
      type: "SET_CURRENT_PAGE",
      payload: currentPage > 1 ? currentPage - 1 : currentPage
    });
  };

  const setCurrentPage = pageNum => dispatch({
    type: "SET_CURRENT_PAGE",
    payload: pageNum
  });

  const sortByPrice = (order = "asc") => dispatch({
    type: "SORT_BY_PRICE",
    payload: {
      order: order
    }
  });

  const sortByAlphabets = (order = "asc") => dispatch({
    type: "SORT_BY_ALPHABETS",
    payload: {
      order
    }
  });

  const loadProducts = (products = []) => dispatch({
    type: "LOAD_PRODUCTS",
    payload: products
  });

  const filterByCategory = filters => {
    let result = [];
    filters.forEach(filter => {
      result = [...result, ...state.data.filter(product => product.category === filter)];
    });
    dispatch({
      type: "FILTER_BY_CATEGORY",
      payload: result.length ? result : state.data
    });
  };

  const filterByPrice = filters => {
    let result = [];
    filters.forEach(({
      min,
      max
    }) => {
      const min_price = Number(min);
      const max_price = Number(max);
      result = [...result, ...state.data.filter(product => product.price >= min_price && product.price <= max_price)];
    });
    dispatch({
      type: "FILTER_BY_PRICE",
      payload: result.length ? result : state.data
    });
  };

  const changeLoadingState = (loading = false) => dispatch({
    type: "IS_LOADING",
    payload: loading
  });

  let clearFilters = () => {};

  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(ProductContext.Provider, {
    value: Products_objectSpread(Products_objectSpread({}, state), {}, {
      changeLoadingState,
      loadProducts,
      clearFilters,
      sortByAlphabets,
      sortByPrice,
      filterByCategory,
      filterByPrice,
      paginate,
      nextPage,
      prevPage,
      currentPage,
      currentProducts,
      productsPerPage,
      totalProducts: filteredProducts.length
    }),
    children: children
  });
};

function useProductContext() {
  const context = Object(external_react_["useContext"])(ProductContext);

  if (context === undefined) {
    throw new Error("useProductContext must be used within a ProductProvider");
  }

  return context;
}


// CONCATENATED MODULE: ./context/Cart/index.tsx


function Cart_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function Cart_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Cart_ownKeys(Object(source), true).forEach(function (key) { Cart_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Cart_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Cart_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const CartContext = /*#__PURE__*/Object(external_react_["createContext"])(undefined);
const Cart_initialState = {
  isOpen: false,
  cartItems: []
};

const Cart_reducerFn = (state = Cart_initialState, action) => {
  switch (action.type) {
    case "OPEN_CART":
      return Cart_objectSpread(Cart_objectSpread({}, state), {}, {
        isOpen: true
      });

    case "CLOSE_CART":
      return Cart_objectSpread(Cart_objectSpread({}, state), {}, {
        isOpen: false
      });

    case "ADD_TO_CART":
      const newProduct = action.payload;
      return Cart_objectSpread(Cart_objectSpread({}, state), {}, {
        cartItems: [...state.cartItems, newProduct]
      });

    case "CLEAR_CART":
      return Cart_initialState;

    default:
      return Cart_initialState;
  }
};

const CartProvider = ({
  children
}) => {
  const {
    0: state,
    1: dispatch
  } = Object(external_react_["useReducer"])(Cart_reducerFn, Cart_initialState);

  const addProductToCart = product => {
    const newCartItem = {
      id: Date.now(),
      product,
      quantity: 1,
      createdAt: new Date()
    };
    dispatch({
      type: "ADD_TO_CART",
      payload: newCartItem
    });
    !state.isOpen && openCart();
  };

  const clearCart = () => {
    dispatch({
      type: "CLEAR_CART"
    });
    closeCart();
  };

  const openCart = () => dispatch({
    type: "OPEN_CART"
  });

  const closeCart = () => dispatch({
    type: "CLOSE_CART"
  });

  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(CartContext.Provider, {
    value: {
      cart: state,
      addProductToCart,
      clearCart,
      openCart,
      closeCart
    },
    children: children
  });
};

function useCartContext() {
  const context = Object(external_react_["useContext"])(CartContext);

  if (context === undefined) {
    throw new Error("useCartContext must be used within a CartProvider");
  }

  return context;
}


// CONCATENATED MODULE: ./context/index.ts



/***/ }),

/***/ "6Fm8":
/***/ (function(module, exports) {



/***/ }),

/***/ "F5FC":
/***/ (function(module, exports) {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cha2":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return App; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("4rth");
/* harmony import */ var _styles_global_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("6Fm8");
/* harmony import */ var _styles_global_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_global_scss__WEBPACK_IMPORTED_MODULE_2__);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



function App({
  Component,
  pageProps
}) {
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(_context__WEBPACK_IMPORTED_MODULE_1__[/* ProductProvider */ "b"], {
    children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(_context__WEBPACK_IMPORTED_MODULE_1__[/* CartProvider */ "a"], {
      children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(Component, _objectSpread({}, pageProps))
    })
  });
}

/***/ })

/******/ });