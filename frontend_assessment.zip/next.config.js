module.exports = {
  images: {
    loader: "imgix",
    path: "https://images.pexels.com",
  },
};
